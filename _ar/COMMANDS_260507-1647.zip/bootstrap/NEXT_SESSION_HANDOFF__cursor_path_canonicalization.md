# Next-session handoff: Cursor commands/skills path canonicalization

**Written:** 2026-05-07 (path-canonicalization session + audit-engine consolidation session)
**Session note:** §3.1 and §6 were corrected after the handoff was initially drafted; a second work block in the same day consolidated `workflow-audit` and `code-audit` into `audit-engine\references\` and converted the reference files to `.yaml`. All sections reflect the final verified disk state.

**Purpose:** Single continuity artifact for any agent starting cold. It explains **why** things broke, **exactly what** was repointed, **what was left alone**, and **what still fails** if you assume old mirror paths.

**Audience:** You are the next agent. Read this before trusting any `@`-command, router contract, `upstream:` YAML, or audit-engine pre-flight that mentions `dev`, `46.07`, or `46.05`.

---

## 1. Problem statement (why sessions "completely fuck up")

A large slice of Cursor command YAML and router docs still assumed an old **mirror tree**:

- `C:\dev\40-49-ai-agents-and-prompts\46-memory-and-bootstrap\46.07-cursor-commands-mirror\...`
- `C:\dev\40-49-ai-agents-and-prompts\46-memory-and-bootstrap\46.05-bootstrap-command-contracts\...`
- Skill mirrors under `...\46.07-cursor-commands-mirror\skills-cursor-mirror\...`

On this machine, **authoritative installs live under the user profile**, not under `C:\dev\...`:

- Commands: `C:\Users\rtoth\.cursor\commands\`
- User skills: `C:\Users\rtoth\.cursor\skills-cursor\`
- Bootstrap contracts (formerly `46.05-bootstrap-command-contracts`): `C:\Users\rtoth\.cursor\commands\bootstrap\`

**Concrete failure modes:**

1. **Audit family:** `@audit-engine` pre-flight **PF-1–PF-3** require three files to be readable at explicit paths. While those pointed at the mirror, pre-flight **hard-failed** even though the real files existed under `.cursor\commands`.
2. **Create-* / master-router:** `router_contract`, `working_directory`, `upstream`, and cited authorities pointed at non-existent paths → operators following docs literally hit missing files.
3. **Bootstrap chain:** `create-bootstrap` and router **`cited_authority` / `upstream`** blocks still referenced `46.05-bootstrap-command-contracts\*.yaml`. Those files **do exist** now as `C:\Users\rtoth\.cursor\commands\bootstrap\*.yaml` (e.g. `bootstrap-start.yaml`, `bootstrap-init.yaml`, …).

---

## 2. Canonical path map (deterministic replacement rules)

Apply these mentally when you see old prose or an old chat log:

| Old prefix | New prefix |
|------------|------------|
| `C:\dev\40-49-ai-agents-and-prompts\46-memory-and-bootstrap\46.07-cursor-commands-mirror\` | `C:\Users\rtoth\.cursor\commands\` |
| `...\46.07-cursor-commands-mirror\skills-cursor-mirror\` | `C:\Users\rtoth\.cursor\skills-cursor\` |
| `C:\dev\40-49-ai-agents-and-prompts\46-memory-and-bootstrap\46.05-bootstrap-command-contracts\` | `C:\Users\rtoth\.cursor\commands\bootstrap\` |

**YAML string nuance:** Many YAML values used **doubled backslashes** before subfolders (`\\create-project\\`). After migration, that pattern is now `C:\Users\rtoth\.cursor\commands\\create-project\\...` — behavior is the same, only the root moved.

**Forward slashes:** `bootstrap-finalize.yaml` `instructions_md` already cites governance as `C:/Users/rtoth/.cursor/commands/bootstrap/COMMAND.md` — that is **consistent** with this layout (forward vs backward slash is OS-normalization territory).

---

## 3. What was changed in this session (inventory)

### 3.1 Audit command family (manual / targeted fixes)

- **`C:\Users\rtoth\.cursor\commands\audit-engine\COMMAND.md`**
  - Pre-flight targets corrected. **Current state** (verified against live file):
    - **PF-1** `target:` → `C:\Users\rtoth\.cursor\commands\audit-engine\COMMAND.md`
    - **PF-2** `target:` → `C:\Users\rtoth\.cursor\commands\audit-engine\references\audit_workflow.yaml`
    - **PF-3** `target:` → `C:\Users\rtoth\.cursor\commands\audit-engine\references\audit_code.yaml`

> **⚠ SUPERSEDED — `workflow-audit` and `code-audit` folders do not exist.**
> The path-canonicalization session initially fixed PF-2/PF-3 to point at `workflow-audit\COMMAND.md` and `code-audit\COMMAND.md`. That state was immediately superseded when both files were consolidated into `audit-engine\references\` and converted to `.yaml`. Neither `C:\Users\rtoth\.cursor\commands\workflow-audit\` nor `...\code-audit\` exists on disk. PF-2/PF-3 now target the `.yaml` reference files above. Do not attempt to read the old standalone `COMMAND.md` paths — they do not exist.

- The `code-review---iterative` skill path fix (from `C:\dev\...` to `%USERPROFILE%\.cursor\skills-cursor\code-review---iterative\SKILL.md`) was incorporated into `audit_code.yaml` during the `.md` → `.yaml` conversion. Verify the fix survived; that skill file may **not** exist locally.

### 3.2 Repo-wide command tree (automated bulk replace)

A one-off PowerShell pass was applied to **text-like files** under `C:\Users\rtoth\.cursor\commands` with extensions `.md`, `.yaml`, `.yml`, `.txt`, `.json`.

**Replacement order (important):** `skills-cursor-mirror` **before** the shorter `46.07-cursor-commands-mirror` prefix, so skill paths did not get half-rewritten.

**17 files updated** (excluding the deleted helper script):

- `corpus-unify\COMMAND.md`
- `create-bootstrap\COMMAND.md`, `create-bootstrap.yaml`
- `create-code\create-code.yaml`
- `create-command\COMMAND.md`, `create-command.yaml`
- `create-corpus\create-corpus.yaml`
- `create-document\COMMAND.md`, `create-document.yaml`
- `create-plan\create-plan.yaml`
- `create-project\COMMAND.md`, `create-project.yaml`
- `create-rule\create-rule.yaml`
- `create-skill\create-skill.yaml`
- `create-subagent\create-subagent.yaml`
- `housekeeping\00_INDEX_AND_SOURCES.md` (only the **housekeeping.yaml** row for the command spec — other rows may still cite unrelated `C:\dev\...` workflow sources)
- `master-router\COMMAND.md` (large authority / pointer block)

**Cleanup:** `C:\Users\rtoth\.cursor\commands\_path_migrate_once.ps1` was **removed** after the run so the commands tree would not contain stale literal prefixes in a stray script.

**Verification:** `rg '46\.07-cursor-commands-mirror' C:\Users\rtoth\.cursor\commands` and `rg '46\.05-bootstrap-command-contracts' C:\Users\rtoth\.cursor\commands` → **no hits outside this handoff file** after cleanup (confirmed by live scan).

### 3.3 Skills tree

- **`C:\Users\rtoth\.cursor\skills-cursor`:** No matches for `46.07-cursor-commands-mirror` / `46.05-bootstrap` after the above work.

---

## 4. Nuance: `bootstrap-finalize.yaml` ↔ this handoff

`C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-finalize.yaml` mandates:

- **`next_session_kickoff`** on persisted project bootstrap YAML under **`{project_root}/02_working/chat-sessions/bootstrap/`**, and
- **Truth anchors** including `COMMAND.md` and `schema.yaml` at
  `C:/Users/rtoth/.cursor/commands/bootstrap/COMMAND.md` and `.../schema.yaml`.

**This markdown file is NOT a substitute for that persisted YAML** (no `project_root` / session id was finalized here). It **is** the detailed narrative you paste into `environment.notes`, `context_file_audit`, or `next_session_kickoff.read_first` when you run finalize for whatever project owns the next session.

---

## 5. Known gaps and footguns (do not lose these)

### 5.1 Router / `master-router` still lists skills that may not exist on disk

Under `C:\Users\rtoth\.cursor\skills-cursor` **today**, folders like **`pdf`**, **`pptx`**, **`xlsx`**, **`labor-type-classifier`** may be **absent** even though `master-router\COMMAND.md` can still **name** those paths after canonicalization. Treat those as **optional or future-sync** unless the operator adds them.

Present skills include at least: `create-rule`, `create-subagent`, `migrate-to-skills`, `shell`, `ontology-tutor`, `canvas`, etc. — see live directory listing when in doubt.

### 5.2 `corpus-unify\SKILL.md`

`corpus-unify\COMMAND.md` may still **describe** a sibling `SKILL.md`. **Only `COMMAND.md` was verified present** in that folder in this session. If something expects `SKILL.md`, either add it or adjust the consumer.

### 5.3 Audit pre-flight **PF-4 / PF-5** (unchanged requirement)

`@audit-engine` still requires **`context-bootstrap`** and **`deterministic-prompt-builder`** in `available_skills`. Path fixes **do not** satisfy those checks if the skills are not registered in the agent context.

**Nuance:** The **governance** package for bootstrap is this repo folder (`commands\bootstrap\`) with front matter `name: context-bootstrap` — do not conflate "skill registration" with "file on disk" without checking Cursor's skill manifest.

### 5.4 Ontology tutor corpus path (not migrated)

`C:\Users\rtoth\.cursor\skills-cursor\ontology-tutor\` still references
`C:/dev/.../46.01-bootstrap-yamls` in `SKILL.md` / `ROUTER.yaml`. That is a **different corpus** from the commands mirror; **no replacement was applied** in this session. Confirmed via live scan: `ROUTER.yaml` contains the `46.01` reference.

### 5.5 Miscellaneous `C:\dev\...` under `commands\housekeeping\` and `create-document\`

Housekeeping index and some archived workflow markdown files still mention **other** `C:\dev\...` trees (n8n workflows, snippet harvest, etc.). Those were **out of scope** for the mirror → `.cursor\commands` migration. Do not assume global search-replace already cleaned every historical reference.

One confirmed stale reference outside the housekeeping scope: **`C:\Users\rtoth\.cursor\commands\create-document\NORTH_STAR.md`** cites `c:\dev\40-49-ai-agents-and-prompts\47-outputs-and-artifacts\47.04-ontology-decision-traces\`. This is a `47.x` path (not `46.07`/`46.05`), was not caught by the migration scan, and is not verified as live or dead.

### 5.6 Orphaned `.md` files in `audit-engine\references\`

After the `.md` → `.yaml` conversion, both stale and active versions coexist on disk:

```
audit-engine\references\audit_code.md       ← stale orphan (do not load)
audit-engine\references\audit_code.yaml     ← active
audit-engine\references\audit_workflow.md   ← stale orphan (do not load)
audit-engine\references\audit_workflow.yaml ← active
```

PF-2 and PF-3 correctly point at the `.yaml` files. However, any agent that enumerates the `references\` directory directly (e.g., `@`-command loading or a listing-based read) may pick up the stale `.md` files and load wrong content. **The `.md` orphans should be deleted or archived; do not load them.**

---

## 6. `read_first` stack for the next agent (minimum)

If you only open three things:

1. `C:\Users\rtoth\.cursor\commands\bootstrap\COMMAND.md` — bootstrap governance (`context-bootstrap`), schema ownership, recovery narrative.
2. `C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-finalize.yaml` — finalize obligations and `next_session_kickoff` contract.
3. **This file:** `...\bootstrap\NEXT_SESSION_HANDOFF__cursor_path_canonicalization.md`

Then branch:

- Router / creation contracts: `C:\Users\rtoth\.cursor\commands\master-router\COMMAND.md`
- Audit orchestration: `...\audit-engine\COMMAND.md`, `...\audit-engine\references\audit_workflow.yaml`, `...\audit-engine\references\audit_code.yaml`

---

## 7. Frozen intent for the next session (non-negotiables)

1. **Treat `C:\Users\rtoth\.cursor\commands\` and `C:\Users\rtoth\.cursor\skills-cursor\` as canonical** for command and user-skill resolution on this machine; **do not** resurrect `46.07-cursor-commands-mirror` or `46.05-bootstrap-command-contracts` paths without verifying the files exist there.
2. **When debugging "pre-flight failed"** on audits: check **PF-1–PF-3 paths first** (PF-2/PF-3 point at `.yaml` reference files, not `COMMAND.md` files), then **PF-4–PF-5 skill registration**.
3. **Before editing router pointers:** grep for any **reintroduced** `C:\dev\40-49-ai-agents` prefixes; keep migration **deterministic** (skills subfolder replaced before parent mirror prefix).
4. **Bootstrap finalize** for the **active project** must still populate `next_session_kickoff` per `bootstrap-finalize.yaml`; this narrative is **supplementary**, not a replacement for project-disk bootstrap YAML.

---

## 8. One-line summary for `session_summary`-style fields

Path canonicalization: migrated Cursor command and router references from `C:\dev\...\46.07-cursor-commands-mirror` and `...\46.05-bootstrap-command-contracts` to `C:\Users\rtoth\.cursor\commands\` (bootstrap YAMLs under `commands\bootstrap\`) and skills mirror to `C:\Users\rtoth\.cursor\skills-cursor\`; consolidated `workflow-audit` and `code-audit` reference files into `audit-engine\references\audit_workflow.yaml` and `audit-engine\references\audit_code.yaml`; fixed audit-engine pre-flight targets; removed temporary migration script; verified no stale mirror prefixes remain under `commands`. Residual risks: orphaned `.md` files in `audit-engine\references\`, optional skills not installed, `corpus-unify` SKILL.md may be absent, ontology-tutor still points at separate `46.01` corpus, housekeeping and `create-document\NORTH_STAR.md` retain unrelated `C:\dev` citations, `audit-engine\COMMAND.md` has 9 pending implementation tasks (ae-3 through ae-8).

---

## 9. Open implementation tasks in `audit-engine\COMMAND.md` (pending)

These tasks were designed in the 2026-05-07 session but **not yet written into `COMMAND.md`**. A cold agent picking up audit-engine work must complete these before the engine is fully coherent. Current audit score: **C tier** (2 CRITICAL, 6 MAJOR, 4 MINOR — `audit_id: AE-20260507-162400`).

| Task ID | Target | Description |
|---------|--------|-------------|
| ae-3 | `§Mixed-content dispatch protocol` — top of section | Add explicit sequencing rule: Phase A MUST reach two consecutive clean passes before Phase B begins; Phase B MUST reach two consecutive clean passes before Phase INT-A begins. |
| ae-4 | `§Integration-Audit Framework` — after I6 | Add I7 (Contract Enforcement Integrity), I8 (Lifecycle and Precondition Chain), I9 (Observable Behavior Alignment / Evidence Fidelity) layer definitions with checks, severity biases, and scoring. |
| ae-5 | `§Integration-audit scoring — integration_layer_weights` | Rebalance weights for 9 layers (currently 6). Proposed: I1=0.20, I2=0.15, I3=0.12, I4=0.10, I5=0.10, I6=0.08, I7=0.12, I8=0.08, I9=0.05 (sum=1.00). |
| ae-6 | `§Integration-specific tier overrides` + `§Integration category enum` | Add tier overrides for I7/I8/I9. Add `CONTRACT_ENFORCEMENT`, `LIFECYCLE_VIOLATION`, `EVIDENCE_GAP` to integration category enum. |
| ae-7 | `§Mixed-content dispatch — Phase C` | Replace Phase C with Phase INT-A (iterative loop until first clean pass across I1–I9) and Phase INT-B (single non-iterative seam-verification pass incorporating seam findings from Domain 1 and Domain 2 audits). |
| ae-8 | `§Procedure Summary — PHASE M block` | Replace "Phase C: integration audit on shared_seam (6 layers)" with Phase INT-A and Phase INT-B lines. Update layer count from 6 to 9. |

**Minor text fixes also pending:**

- `§Invocation — examples block, first bullet`: Change "default mode by content type" → "iterative mode (unconditional default)"
- `§Integration-Audit Framework header`: Change "Layers (6)" → "Layers (9)"
- `§What this command is — integration-audit framework bullet`: Change "six layers" → "nine layers"

---

_End of handoff. Preserve this file or merge its content into your project bootstrap when running `bootstrap-finalize`._
