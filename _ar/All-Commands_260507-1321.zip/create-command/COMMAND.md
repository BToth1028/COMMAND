---
name: create-command
description: >-
  DRAFT master-router COMMAND child. Validates dispatch_table.COMMAND handoff; chain not run.
---

# Create-command (draft)

Validate thirteen frozen fields listed in **`create-command.yaml`** (mirrors router **`required_inputs`**). When BUILT: **`COMMAND.md`** at **`C:\dev\40-49-ai-agents-and-prompts\46-memory-and-bootstrap\46.07-cursor-commands-mirror\{command_name}\`** plus tier-aware **`NORTH_STAR.md`**.

## Inputs

`python create-command_run.py --handoff-json <path>`

## Exit 2

`DRAFT_ONLY` after key audit.
