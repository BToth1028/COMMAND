# Housekeeping documentation harvest — index

Generated: 2026-04-24. This folder contains copies of primary sources found by searching `c:\code` and `C:\Users\rtoth\code` (and related Cursor paths) for file housekeeping: automated cleanup, old-file triage, merge/delete/archive routing, and snippet library flows.

## Files copied into this folder (verbatim)

| Local copy | Original path |
|------------|---------------|
| `housekeeping.yaml` | `C:\Users\rtoth\.cursor\commands\housekeeping\housekeeping.yaml` — **Cursor command spec**: session file review, PARA placement, stub/duplicate detection, soft delete, merge proposals, git hints. |
| `c-code__staging__Automation__n8n__kn.wkfl.00.01.19_housekeep.md` | `c:\code\_staging\Automation\n8n\kn.wkfl.00.01.19_housekeep.md` — **workflow doc**: delt-scan → pend-clnp → fldr-clnp; n8n integration. |
| `c-code__staging__Automation__n8n__kn.wkfl.00.01.19_file-mant.md` | `c:\code\_staging\Automation\n8n\kn.wkfl.00.01.19_file-mant.md` — **file maintenance**: newest-first inventory, concept review, 4-axis grading, route PROMOTE/REFINE/HOLD/ARCHIVE/DELETE, then fldr-clnp. |
| `rtoth-code__va__ar__Automations__Workflows__proc-housekeep.json` | `C:\Users\rtoth\code\va\ar\Automations\Workflows\proc-housekeep.json` — **n8n orchestrator** calling mod-delt-scan, mod-pend-clnp, mod-fldr-clnp. |
| `c-code__staging__snip-stor__kn.wkfl.00.01.19_snip-stor.md` | `c:\code\_staging\0.U_Inbox\KT\~~~CURRENT~~~\02_most\kn.wkfl.00.01.19_snip-stor.md` — **snippet storage** to `li/code/snippets/`. |
| `c-code__staging__snip-harv__kn.wkfl.00.01.19_snip-harv.md` | `c:\code\_staging\0.U_Inbox\GOVERNANCE\z9-trash\Workflows\kn.wkfl.00.01.19_snip-harv.md` — **snippet harvest** from source files. |
| `cursor_plans__housekeeping_system_completion_6c3bfff8.plan.md` | `C:\Users\rtoth\.cursor\plans\housekeeping_system_completion_6c3bfff8.plan.md` — plan tying file-mant, modules, n8n, cross-ref work. |
| `cursor_plans__housekeeping_batch_p5_9f85cc6d.plan.md` | `C:\Users\rtoth\.cursor\plans\housekeeping_batch_p5_9f85cc6d.plan.md` — **note:** “housekeeping” here is a **DB/Utilix batch** (tblAuditLog, cardinality, axioms doc), not general file cleanup. |
| `rtoth-code__specstory__housekeeping-procedure-summary_EXCERPT.md` | Excerpt from SpecStory (see below). |

## Additional locations (not duplicated — duplicates or chat logs)

- **SpecStory (full, large):** `C:\Users\rtoth\code\.specstory\history\2026-01-22_10-35Z-housekeeping-procedure-summary.md` — includes an agent summary of a **7-step** `kn.proc.00.01.19_housekeep` procedure; that path was under `c:\Users\rtoth\code\kv\30_Knowledge\Procedures\` in that older workspace layout (not present under `c:\code` today).
- **Governance merge chat:** `C:\Users\rtoth\code\.specstory\history\2026-02-11_19-05Z-bootstrap-and-todo-list-summary.md` — `housekeep` vs `file-mant` redundancy, merge n8n into file-mant, archive workflows.
- **Duplicate staging copies** of the same n8n workflow under e.g. `c:\code\_staging\Utilix\01-context\sessions\Raw\260407\...\Automation\n8n\` and FormBuilder staging (same content as the canonical `_staging\Automation\n8n` copy).
- **Utilix bootstraps** reference the Cursor `housekeeping` command decision records: `c:\code\_staging\Utilix\bootstrap\Utilix_260416-*.yaml` (domain: housekeeping).

## Theme map (what handles “old files”)

1. **Automated / scheduled (repo hygiene):** `kn.wkfl` housekeep + `proc-housekeep.json` (delta scan, pending deletion folders, empty folders).
2. **Human-in-the-loop triage of legacy files:** `kn.wkfl` file-mant (grading matrix, archive/delete, promote to file-comp).
3. **Cursor command “housekeeping”:** `housekeeping.yaml` — session-touched files, merge/remove/relocate with approval.
4. **Preserving code as reusable assets:** `snip-harv` + `snip-stor` (snippet library at `li/code/snippets/`).

## Missing from this repo root

- `c:\code\kv\30_Knowledge\Procedures\kn.proc.00.01.19_housekeep.md` was **not found** under `c:\code` (only referenced in old SpecStory / external tree).
