---
name: corpus-unify
description: Merges multiple related documents in a folder into one deduplicated reference file while preserving every source’s unique facts and surfacing conflicts. Inventory assumes processes are automatable until a defensible cannot/should-not is recorded. Use when the user wants a single coherent corpus, unified reference, “dedupe but keep unique content from each file,” folder merge, or consolidation of overlapping docs (not summarization to one page, not formal scoring registries like R*/Q* unless requested).
---

# Corpus unify (deduplicate + unique retention)

## Purpose

Build **one** markdown file that a human can use as the **operational reference** for a **multi-file corpus**: overlap is stated **once**; information that appears in only one source is **kept**; **contradictions and homonyms** are made explicit, not hidden.

This is **not** the same as:

- **Structural reconstruction** (heavy deletion, claim atomization, short output) — use that skill when the goal is a compressed cognitive skeleton, not a merged manual.
- **Multi-session / blueprint distillation** (R*, Q*, tier scoring, test matrices) — use only when the user explicitly wants that audit-style artifact.
- **Copy-paste concatenation** — forbidden as the default outcome.

## Automation default (inventory attitude)

When scanning the **corpus root** and everything it implies across the folder structure—files **and** what they describe or drive (scripts, schedules, containers, MCP, webhooks, operator checklists, services, queues):

- **Base assumption:** any repeated, cross-boundary, or trigger-like activity **can** be automated until a **defensible** barrier is written down.
- **Forbidden default:** asking only whether something *might* be automated (“if we could…”) leaves manual work falsely neutral.
- **Required default:** ask **why it cannot** be automated, or **why it should not** be—hard **cannot** (no machine interface, unknowable inputs, cryptographic human step, physical reality, immutable policy prohibition) versus **should not** (risk, loss of determinism, compliance, economics, lawful human accountability—tie to **sources** where the corpus supplies them; label **operator preference** explicitly when inferred).
- Treat **currently manual or semi-manual** practice in the corpus as **automation gap or deliberate exception**, not an inherent category, unless barriers are stated above.

Fold this into the merge: do not ship a sermon—surface it in **Gaps**, **Merged narrative**, and/or **Conflicts**, and in the **Self-check**.

## Triggers

Use this skill when the user (or task) mentions any of: unified document, single reference, merge folder, deduplicate documentation, combine sources, one file from many, unique content per file, overlap folded, consolidated corpus, “like `housekeeping_unified_corpus`,” or disambiguation of overloaded terms.

## Required inputs

- **Corpus root**: path to a directory **or** explicit list of file paths.
- **Output path** (or name): where to write the unified file; default is `{corpus_root}/{topic}_unified_corpus.md` if unspecified.
- **Exclusions** (optional): glob patterns or names to skip (e.g. prior bad distillations, chat logs, `node_modules`).

If the corpus root is missing, ask before writing.

## Non-negotiable output contract

1. **Provenance first**: a table or list mapping **each** ingested file to one row (name + one-line role). Excluded files named under “Exclusions.”
2. **Deduped substance**: a fact that appears in multiple sources appears **once**, with “(repeated in A, B)” only if traceability is required; otherwise state the fact once in the most natural section.
3. **Context delta retention**: pure duplicate data is removed; when two sources repeat the same fact but one source adds decision-relevant context, rationale, constraints, examples, edge cases, or operator guidance, preserve only that extra context as an incremental delta.
4. **Per-source unique facts**: for every file, at least one **non-redundant** fact, procedure, or context delta must appear in the merged doc **unless** the file is empty or fully duplicated (then state “fully subsumed by X”).
5. **Conflicts visible**: if two sources disagree (numbers, names, order, or filenames), do **not** pick silently — use a **Conflicts / resolution** or **per-source note** (e.g. “Workflow says `snip-{slug}`; storage doc says `snip-{hash}` — reconcile before import”).
6. **Disambiguation section** when the same word labels different systems (e.g. “housekeeping” = Cursor command vs n8n vs DB batch). Short numbered list, each item **what it is / what it is not**.
7. **Pointer to authority**: where the full verbatim spec is huge (e.g. long YAML), **summarize** with the critical operators/thresholds and say “full text: `[path]`.”
8. **Quick lookup** table at the end: “If you need to … → open …” with concrete paths.
9. **Automation frontier:** across **everything the inventory reveals** about how work is done or executed (including latent paths in prose or config), briefly map **candidate automation surfaces** and, for anything that remains manual or partial **in authoritative sources**, attach a **cannot** or **should not** rationale. Unresolved claims need the **hypothesis:** label—never silent resignation to “mostly manual.”

## Forbidden

- Silently favoring the newest file when sources conflict.
- Replacing the merge with a registry-only artifact (R*, Q*, scoring dimensions) **unless the user asked for that**.
- Dropping a source file from the folder without mentioning it in provenance (either merged or listed as skipped with reason).
- Inventing procedures not present in any source (hypotheses must be labeled as such or omitted).
- Treating “human step” as the default destiny for any described flow **without** a written **cannot / should not** barrier.

## Execution workflow

### Step 1 — Inventory

- List all files in scope (respect exclusions).
- Classify each file: **index/map**, **full spec**, **plan/roadmap**, **executable config** (JSON/YAML), **historical/excerpt**, **out-of-domain homonym** (same word, different project).
- Trace **executable reality**: triggers, binaries, pipelines, cron, credentials, approvals, MCP or API calls, queues, watcher folders—anything implied as **actually running**, not prose-only ideals.
- For each surfaced process, assume **automatable**: record only **blocking** or **rightful-non-automation** reasons (see Automation default)—not “might automate someday.”

### Step 2 — Build a private overlap map (no need to show unless useful)

- For each pair of files, note repeated facts (same step order, same numbers, same module names).
- Mark **unique** bullets per file: only one file says it → must survive in the unified doc.
- Mark **context deltas** separately from facts: if the data/fact repeats but one file explains why it matters, when it applies, how to choose, or what failure it prevents, keep the explanatory delta and discard only the duplicated data.

### Step 3 — Write sections (suggested order)

1. **Title + scope** (what the merged file is and is not).
2. **Provenance table** (and exclusions).
3. **Disambiguation** (if overload exists).
4. **Merged narrative by concern** (e.g. “operator command,” “automation,” “human workflow,” “roadmap — not current behavior”), not by source filename — *except* when two sources are truly different “lanes” and stacking them under one heading would hide boundaries.
5. **Source-specific islands** only when needed: e.g. “DB batch (only in `…plan.md`)” so unique content is not smeared into wrong lane.
6. **Gaps** (index notes missing files, missing paths, excerpt-only content)—include **manual or partial-automation deltas** paired with **why can’t / why shouldn’t**, per Automation default where material exists.
7. **Quick lookup** table.

### Step 4 — Deduplication rules

- **Same fact, same wording** → one paragraph.
- **Same fact, extra context** → one paragraph for the fact plus only the extra context/rationale/edge case from the richer source; do not duplicate the base fact.
- **Pure data duplication** → retain one canonical instance only; repeated tables, lists, enum values, paths, IDs, counts, or command blocks are not repeated unless a conflict or version difference exists.
- **Same fact, different numbers** → conflict list.
- **Subset relationship** → keep the **superset** in body; one line “[smaller file] is subsumed except …” for any delta.
- **Config vs prose** (e.g. n8n JSON + markdown): merge into one **Automation** section; **concrete** timeouts, JSON keys, and URLs from the **config**; narrative and “when to use” from **markdown**.

### Step 5 — Self-check before handoff

- [ ] Every file in the inventory (except explicit exclusions) is either reflected in the body or called out as fully subsumed.
- [ ] Repeated data was deduped, but decision-relevant context deltas from repeated sections were preserved.
- [ ] No contradiction left implicit.
- [ ] One place answers “which document do I open for X?”
- [ ] Automation default honored: observable execution paths inventoried under **assume automatable**, and lingering manual/semi-manual posture has stated **cannot** or **should not** (or **`hypothesis:`** where unknowable)—not tacit assumptions.

## File placement

- **Cursor command**: `C:\Users\rtoth\.cursor\commands\corpus-unify\COMMAND.md` — canonical command file.
- **Companion skill-style trigger file**: `C:\Users\rtoth\.cursor\commands\corpus-unify\SKILL.md` — mirrors command behavior for skill-style discovery only; it is not the canonical command contract.

## Example section skeleton (template)

```markdown
# {Topic} — unified reference (from `{corpus_root}`)

**Sources folded:** [table]
**Exclusions:** [list or “none”]

## 1. What “{overloaded term}” means (if applicable)
- Lane A: …
- Lane B: …

## 2. {First concern} (deduped)
…

## N. Gaps and excerpts
…

## Quick lookup
| I need to … | Open |
|-------------|------|
| … | `path` |
```

## Relation to other skills

- **structural-reconstruction**: compress and classify claims; use when the deliverable is **short** and **insight-dense**, not a merged manual.
- **prompt-builder**: if the user wants a **reusable machine prompt** for future corpus merges, translate this workflow into YAML-first prompt blocks there.
- **writing-plans**: if the corpus is huge or high-risk, write a one-page plan and get approval before generating the unified file.
