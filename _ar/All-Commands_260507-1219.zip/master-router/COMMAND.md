---
name: master-router
description: >-
  Deterministic creation router. Classifies any request to create a new
  artifact (project, document, code file, Cursor rule, subagent, skill,
  command, plan triplet, unified corpus), validates preconditions, and
  dispatches exactly one child command (atomic) or an ordered chain. Owns
  the closed-world request_type enum, dispatch table, precondition gates,
  decision-trace schema, error policy, and anti-drift contract for all
  creation work. Audits, transformations, recoveries, and lifecycle
  operations are explicitly out of scope. Halt is preferred over guessing.
---

# Master Router (creation-domain dispatcher)

This file is the canonical governance and dispatch contract for any request
that creates a new artifact under the user's control. It is a router only:
it never produces the artifact itself. It classifies intent, validates
preconditions, freezes inputs, emits a decision_trace, and hands off to
exactly one child command — or halts with a structured error. Children
referenced below are stubs until separately authored; invoking a stub
returns `CHILD_NOT_BUILT` with the full handoff envelope so the child can
be built against the exact contract the router will pass it.

```yaml
# ==============================================================================
# IDENTITY
# ==============================================================================
command: master-router
type: router
phase: 0.0
classification: governance_and_dispatch
governed_by: this_file
authority_for:
  - creation_request_classification
  - precondition_gate_evaluation_for_creation_work
  - dispatch_to_creation_child_commands
  - decision_trace_emission_for_creation_requests
not_authority_for:
  - session_lifecycle_management         # owned by commands/bootstrap
  - audit_or_review_of_existing_artifacts # owned by audit-engine / workflow-audit / code-audit
  - housekeeping_or_archival             # owned by commands/housekeeping
  - distillation_or_research             # owned by commands/distillation, commands/research
  - corpus_unify_methodology_authoring   # owned by commands/corpus-unify (router invokes it as a child)
  - the_actual_creation_work             # owned by child commands and underlying skills

governs:
  - file: create-project.yaml
    status: STUB_PENDING_BUILD
    request_type: PROJECT
    canonical_path: "C:\\Users\\rtoth\\.cursor\\commands\\create-project\\create-project.yaml"
  - file: create-bootstrap.yaml
    status: STUB_PENDING_BUILD
    request_type: BOOTSTRAP
    canonical_path: "C:\\Users\\rtoth\\.cursor\\commands\\create-bootstrap\\create-bootstrap.yaml"
  - file: create-document.yaml
    status: BUILT
    request_type: DOCUMENT
    canonical_path: "C:\\Users\\rtoth\\.cursor\\commands\\create-document\\create-document.yaml"
  - file: create-code.yaml
    status: STUB_PENDING_BUILD
    request_type: CODE
    canonical_path: "C:\\Users\\rtoth\\.cursor\\commands\\create-code\\create-code.yaml"
  - file: create-rule.yaml
    status: STUB_PENDING_BUILD
    request_type: RULE
    canonical_path: "C:\\Users\\rtoth\\.cursor\\commands\\create-rule\\create-rule.yaml"
  - file: create-subagent.yaml
    status: STUB_PENDING_BUILD
    request_type: SUBAGENT
    canonical_path: "C:\\Users\\rtoth\\.cursor\\commands\\create-subagent\\create-subagent.yaml"
  - file: create-skill.yaml
    status: STUB_PENDING_BUILD
    request_type: SKILL
    canonical_path: "C:\\Users\\rtoth\\.cursor\\commands\\create-skill\\create-skill.yaml"
  - file: create-command.yaml
    status: STUB_PENDING_BUILD
    request_type: COMMAND
    canonical_path: "C:\\Users\\rtoth\\.cursor\\commands\\create-command\\create-command.yaml"
  - file: create-plan.yaml
    status: STUB_PENDING_BUILD
    request_type: PLAN
    canonical_path: "C:\\Users\\rtoth\\.cursor\\commands\\create-plan\\create-plan.yaml"
  - file: create-corpus.yaml
    status: STUB_PENDING_BUILD
    request_type: CORPUS_UNIFY
    canonical_path: "C:\\Users\\rtoth\\.cursor\\commands\\create-corpus\\create-corpus.yaml"

# ==============================================================================
# MISSION
# ==============================================================================
mission:
  objective: >
    For every operator request to create a new artifact, deterministically
    classify the request_type from a closed-world enum, resolve subtype and
    target path, run precondition gates, freeze inputs, emit a complete
    decision_trace, and dispatch to exactly one child command (atomic) or
    an ordered chain — or halt with a structured error. Never execute the
    creation itself. Never silently default. Never auto-overwrite.

  scope:
    in_scope:
      - classify_creation_intent_to_one_request_type_in_enum
      - resolve_subtype_when_request_type_has_subtypes
      - resolve_target_path_absolute_or_halt
      - run_precondition_gates_in_fixed_order
      - freeze_user_inputs_into_handoff_envelope
      - select_dispatch_kind_atomic_or_chain
      - emit_decision_trace_on_every_terminus_success_clarification_or_halt
      - return_clarification_request_when_intent_is_ambiguous
      - return_structured_error_envelope_on_any_gate_failure
      - report_CHILD_NOT_BUILT_with_full_handoff_envelope_when_target_child_is_a_stub

    out_of_scope:
      - executing_the_creation_work_itself
      - reading_or_modifying_upstream_canonical_commands_or_skills
      - audit_review_critique_or_code_review_of_existing_artifacts
      - housekeeping_archival_distillation_research_recovery
      - transformation_or_reformatting_of_existing_artifacts
      - silently_overwriting_any_existing_file
      - inferring_user_intent_when_signals_are_ambiguous
      - bypassing_bootstrap_session_lifecycle_for_project_bound_creation
      - inventing_a_new_request_type_or_subtype_inline
      - choosing_among_multiple_plausible_classifications_without_clarification
      - emitting_preamble_or_postamble_outside_the_output_contract

  gray_zone_policy: >
    If a request does not unambiguously map to exactly one request_type:
      1. Emit a clarification_request envelope containing:
           - the request as received (verbatim)
           - the candidate request_types considered (max 3)
           - the discriminating signal needed to pick
           - one binary or short-list question per ambiguity dimension
      2. HALT until the operator answers. Never guess. Never default to the
         most common type.

  success_criteria:
    - exactly_one_request_type_selected_from_enum
    - exactly_one_dispatch_path_selected_atomic_or_chain
    - all_precondition_gates_passed_or_a_recoverable_clarification_returned
    - handoff_envelope_complete_and_schema_valid
    - decision_trace_present_complete_and_consistent_with_dispatch
    - no_forbidden_output_elements_present

  failure_criteria:
    - request_type_unresolved_at_dispatch_step
    - more_than_one_request_type_marked_selected
    - any_precondition_gate_silently_skipped
    - handoff_envelope_missing_required_field
    - decision_trace_missing_or_inconsistent
    - dispatch_to_child_not_in_governs_list
    - any_creation_work_attempted_inside_router

# ==============================================================================
# AUTHORITY MODEL
# ==============================================================================
authority_model:
  trust_hierarchy:
    - level_1: this_router_COMMAND_md
    - level_2: child_command_files_when_built          # create-project.yaml, etc.
    - level_3: upstream_canonical_governance           # bootstrap/COMMAND.md, planning/project-plan-builder.yaml, corpus-unify/COMMAND.md
    - level_4: upstream_canonical_skills               # skills-cursor/create-rule, skills-cursor/create-subagent, skills-cursor/migrate-to-skills, skills-cursor/{pdf,pptx,xlsx}
    - level_5: operator_input_in_current_session
    - level_6: agent_training_knowledge                # syntax mechanics only, never project content

  canonical_sources:
    - source: C:\Users\rtoth\.cursor\commands\bootstrap\COMMAND.md
      canonical_for: bootstrap_protocol_governance_session_lifecycle_session_zero_recovery
    - source: C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-start.yaml
      canonical_for: operator_driven_path_selection_path1_path2_path3_session_zero
    - source: C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-init.yaml
      canonical_for: session_zero_construction_requires_project_name_and_project_root
    - source: C:\Users\rtoth\.cursor\commands\planning\project-plan-builder.yaml
      canonical_for: project_plan_triplet_milestone_execution_todo_no_time_estimation_one_project_per_session
    - source: C:\Users\rtoth\.cursor\skills-cursor\create-rule\SKILL.md
      canonical_for: cursor_rules_mdc_format_in_dot_cursor_rules_directory
    - source: C:\Users\rtoth\.cursor\skills-cursor\create-subagent\SKILL.md
      canonical_for: cursor_subagents_md_format_in_dot_cursor_agents_or_user_agents
    - source: C:\Users\rtoth\.cursor\skills-cursor\migrate-to-skills\SKILL.md
      canonical_for: skill_md_format_for_authoring_new_skills
    - source: C:\Users\rtoth\.cursor\commands\corpus-unify\COMMAND.md
      canonical_for: corpus_unify_methodology_dedupe_overlap_preserve_unique_surface_conflicts_automation_default
    - source: C:\Users\rtoth\.cursor\skills-cursor\pdf\SKILL.md
      canonical_for: pdf_creation_and_form_handling
    - source: C:\Users\rtoth\.cursor\skills-cursor\pptx\SKILL.md
      canonical_for: pptx_presentation_creation
    - source: C:\Users\rtoth\.cursor\skills-cursor\xlsx\SKILL.md
      canonical_for: xlsx_workbook_creation

  derived_sources:
    - source: this_router_COMMAND_md
      derived_from: canonical_sources_above_via_corpus_unify_methodology
      rebuild_rule: regenerate_router_from_canonicals_when_any_canonical_changes_materially

  conflict_resolution:
    - rule: upstream_canonical_governance_wins_over_router_when_router_disagrees_with_bootstrap_or_planner
    - rule: bootstrap_session_lifecycle_authority_is_absolute_for_project_bound_creation
    - rule: planner_status_enum_locked_at_init_authority_is_absolute_for_PLAN_dispatch
    - rule: corpus_unify_output_contract_is_absolute_for_CORPUS_UNIFY_dispatch
    - rule: when_two_canonicals_conflict_router_HALTs_with_UPSTREAM_AUTHORITY_CONFLICT_and_cites_both_paths

# ==============================================================================
# CLOSED-WORLD ENUMS
# ==============================================================================
request_type_enum:
  PROJECT:
    description: >
      Create a brand-new project from zero. Bundles bootstrap session-zero,
      live bootstrap directory creation, project plan triplet creation, and
      optionally seeds initial Cursor rules. Operator must supply
      project_name and absolute project_root.
    canonical_chain_origin:
      - C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-start.yaml#path_3_session_zero
      - C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-init.yaml#session_zero_flag_true
      - C:\Users\rtoth\.cursor\commands\planning\project-plan-builder.yaml#create_milestone_plan
  BOOTSTRAP:
    description: >
      Initialize a bootstrap session-zero for an existing project_root that
      has no bootstrap directory yet. Standalone — does NOT create plan
      triplet or rules. Use when the operator already laid down the project
      tree manually and only needs the bootstrap protocol applied.
    canonical_chain_origin:
      - C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-start.yaml#path_3_session_zero
      - C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-init.yaml#session_zero_flag_true
  DOCUMENT:
    description: >
      Create a new document file. Subtype required.
    subtype_enum: [md, docx, pptx, xlsx, pdf, html, txt, yaml, json, csv]
    canonical_chain_origin:
      - skills-cursor/docx (where applicable)
      - skills-cursor/pptx
      - skills-cursor/xlsx
      - skills-cursor/pdf
      - native_write_for_md_html_txt_yaml_json_csv
  CODE:
    description: >
      Create a new source code file or module. Language declared by
      operator or inferred from extension. Router does not evaluate
      correctness — it only places the file according to project
      conventions. Hands off code review to audit-engine / code-audit
      AFTER creation if requested separately.
    subtype_enum: free_text_language_label   # e.g., python, typescript, go, sql, powershell, batch, rust
  RULE:
    description: >
      Create a Cursor rule (.mdc) under .cursor/rules/. Operator must
      supply description, scope (alwaysApply or globs), and rule body.
    canonical_chain_origin:
      - C:\Users\rtoth\.cursor\skills-cursor\create-rule\SKILL.md
  SUBAGENT:
    description: >
      Create a Cursor subagent (.md) under .cursor/agents/ (project) or
      ~/.cursor/agents/ (user). Operator must supply name, description,
      system prompt body, and scope.
    canonical_chain_origin:
      - C:\Users\rtoth\.cursor\skills-cursor\create-subagent\SKILL.md
  SKILL:
    description: >
      Create a new SKILL.md under .cursor/skills/{skill-name}/ (project)
      or ~/.cursor/skills/{skill-name}/ (user). Operator must supply name,
      description, and skill body. NOT migration — migration of an
      existing rule or command into a skill is a separate concern handled
      by skills-cursor/migrate-to-skills.
    canonical_chain_origin:
      - C:\Users\rtoth\.cursor\skills-cursor\migrate-to-skills\SKILL.md#conversion_format
    forbidden_overlap:
      - request_type: RULE  # SKILL.md and .mdc rule are distinct artifacts
      - request_type: COMMAND  # SKILL.md and COMMAND.md are distinct artifacts
  COMMAND:
    description: >
      Create a new command file (COMMAND.md or *.yaml) under
      C:\Users\rtoth\.cursor\commands\{command-name}\. Operator must
      supply name, description, and command body conforming to the schema
      shape used by upstream commands (mission, scope, non_scope, authority,
      inputs, algorithm, output_contract, validation_gates, error_policy,
      anti_drift).
  PLAN:
    description: >
      Create a project plan triplet (or one of its components) for an
      EXISTING project that already has a bootstrap. Wraps the planner's
      create_milestone_plan or create_execution_plan operations. Use
      complete/update operations of the planner are NOT covered by this
      router (those are mutations, not creation).
    canonical_chain_origin:
      - C:\Users\rtoth\.cursor\commands\planning\project-plan-builder.yaml#create_milestone_plan
      - C:\Users\rtoth\.cursor\commands\planning\project-plan-builder.yaml#create_execution_plan
  CORPUS_UNIFY:
    description: >
      Create a unified-reference markdown by distilling a multi-file
      corpus. Wraps commands/corpus-unify methodology. Operator must
      supply corpus_root or explicit file list, output_path, and optional
      exclusions.
    canonical_chain_origin:
      - C:\Users\rtoth\.cursor\commands\corpus-unify\COMMAND.md
  UNKNOWN:
    description: >
      Reserved terminus. Set when classification cannot resolve to any
      other enum value after exhausting classification_rules. Always
      triggers clarification_protocol — never dispatched to a child.

document_subtype_enum:
  md:    {file_extension: ".md",    skill_required: false, default_writer: native_write}
  docx:  {file_extension: ".docx",  skill_required: true,  default_writer: skills_cursor_docx_or_workspace_skill}
  pptx:  {file_extension: ".pptx",  skill_required: true,  default_writer: skills_cursor_pptx}
  xlsx:  {file_extension: ".xlsx",  skill_required: true,  default_writer: skills_cursor_xlsx}
  pdf:   {file_extension: ".pdf",   skill_required: true,  default_writer: skills_cursor_pdf}
  html:  {file_extension: ".html",  skill_required: false, default_writer: native_write}
  txt:   {file_extension: ".txt",   skill_required: false, default_writer: native_write}
  yaml:  {file_extension: ".yaml",  skill_required: false, default_writer: native_write}
  json:  {file_extension: ".json",  skill_required: false, default_writer: native_write}
  csv:   {file_extension: ".csv",   skill_required: false, default_writer: native_write}

dispatch_kind_enum: [ATOMIC, CHAIN]

# ==============================================================================
# TIER SYSTEM + INTENT ANCHOR (anti-drift north-star architecture)
# ==============================================================================
tier_enum: [TIER_0, TIER_1, TIER_2, TIER_3]

tier_definitions:
  TIER_0:
    label: ephemeral
    description: >
      Operator-declared throwaway creation. No intent_anchor required, no
      decision_trace persistence to audit store (in-session emission only),
      no governance association. Wrong-lane rejection (audit/transform/
      recovery) and path/overwrite/writability gates STILL run — those
      protect the filesystem and are non-negotiable for any creation.
      TIER_0 is operator-explicit only; the router NEVER defaults to it.
    eligible_request_types: [DOCUMENT, CODE]
    forbidden_request_types: [PROJECT, BOOTSTRAP, RULE, SUBAGENT, SKILL, COMMAND, PLAN, CORPUS_UNIFY]
    intent_anchor_required: false
    intent_brief_required: false
    north_star_md_required: false
    decision_trace_persisted: false
    governance_state_forced: UNGOVERNED_NO_PROJECT_CONTEXT

  TIER_1:
    label: compact
    description: >
      Anchor required: purpose + non_scope + success_criterion only.
      intent_brief NOT required. Suitable for short structural artifacts
      whose substance is captured in their body or in upstream canonicals.
    eligible_request_types: [BOOTSTRAP, RULE, SUBAGENT, PLAN_create_execution_plan]
    intent_anchor_required: true
    intent_brief_required: false
    north_star_md_required: false
    decision_trace_persisted: true

  TIER_2:
    label: standard
    description: >
      Anchor required: purpose + non_scope + success_criterion + inline
      intent_brief (1-3 paragraphs covering domain context, key behaviors,
      failure modes / what drift looks like). Default for substantive but
      bounded artifacts.
    eligible_request_types: [DOCUMENT, CODE, PLAN_create_milestone_plan]
    intent_anchor_required: true
    intent_brief_required: true
    intent_brief_format: inline_paragraphs
    intent_brief_required_sections:
      - domain_context
      - key_behaviors
      - failure_modes_what_drift_looks_like
    north_star_md_required: false
    decision_trace_persisted: true

  TIER_3:
    label: deep
    description: >
      Anchor required: purpose + non_scope + success_criterion +
      standalone NORTH_STAR.md file alongside the artifact. The
      NORTH_STAR.md is created as part of dispatch (chain step or sibling
      output). Used when the artifact is structural enough that a future
      agent or operator must walk in cold and understand context,
      principles, boundaries, glossary, failure modes, and upstream
      inheritance.
    eligible_request_types: [PROJECT, SKILL, COMMAND, CORPUS_UNIFY]
    intent_anchor_required: true
    intent_brief_required: true
    intent_brief_format: standalone_north_star_md_file
    north_star_md_required: true
    north_star_md_required_sections:
      - context
      - principles
      - boundaries_with_rationale
      - key_concepts_glossary
      - failure_modes
      - upstream_inheritance
      - decision_log_pointer
    decision_trace_persisted: true

default_tier_per_request_type:
  PROJECT: {default: TIER_3, downgrade_forbidden: true, hard_lock_rationale: "projects without a NORTH_STAR.md cannot survive multiple sessions without drift"}
  BOOTSTRAP: {default: TIER_1, downgrade_forbidden: false}
  DOCUMENT: {default: TIER_2, downgrade_forbidden: false, downgrade_to_TIER_0_eligible: true}
  CODE: {default: TIER_2, downgrade_forbidden: false, downgrade_to_TIER_0_eligible: true}
  RULE: {default: TIER_1, downgrade_forbidden: false}
  SUBAGENT: {default: TIER_1, downgrade_forbidden: false}
  SKILL: {default: TIER_3, downgrade_forbidden: true, hard_lock_rationale: "skills are reused across sessions and projects; ungoverned authoring causes silent capability drift"}
  COMMAND: {default: TIER_3, downgrade_forbidden: true, hard_lock_rationale: "commands are governance artifacts; their own anti-drift protocol depends on a stable north-star anchor"}
  PLAN_create_milestone_plan: {default: TIER_2, downgrade_forbidden: false}
  PLAN_create_execution_plan: {default: TIER_1, downgrade_forbidden: false}
  CORPUS_UNIFY: {default: TIER_3, downgrade_forbidden: true, hard_lock_rationale: "unified-reference outputs are canonical reference material; the synthesis must be anchored against the original sources to remain trustworthy"}
  notes:
    - default_is_proposed_to_operator_at_step_6_confirm_tier
    - operator_can_confirm_default_or_override_to_higher_or_eligible_lower_tier
    - downgrade_forbidden_request_types_REJECT_any_operator_downgrade_attempt_no_justification_path
    - downgrade_to_TIER_0_requires_request_type_in_TIER_0_eligible_request_types
    - upgrade_path_always_open_higher_tier_supersedes_default

tier_promotion_rules:
  - rule: operator_can_always_bump_tier_higher_than_default
    rationale: more_anchoring_is_never_unsafe
  - rule: operator_can_only_drop_to_TIER_0_if_request_type_is_DOCUMENT_or_CODE
    rationale: structural_artifacts_require_anchoring_by_definition
  - rule: operator_cannot_drop_below_default_within_anchored_tiers_without_explicit_justification
    rationale: defaults_are_calibrated_per_request_type_silent_downgrade_is_drift
  - rule: PROJECT_SKILL_COMMAND_CORPUS_UNIFY_cannot_be_downgraded_below_TIER_3_under_any_circumstance
    rationale: hard_locked_per_default_tier_per_request_type_downgrade_forbidden_flag
    enforcement: HALT_TIER_DOWNGRADE_FORBIDDEN_no_justification_path_exists
  - rule: tier_locked_at_step_6_cannot_be_modified_after_freeze_inputs
    rationale: dispatch_envelope_must_be_stable

intent_anchor_schema:
  purpose:
    type: string
    length: 1_to_3_sentences
    required_at_tiers: [TIER_1, TIER_2, TIER_3]
    role: glanceable_headline_zero_context_test_drift_comparator
  non_scope:
    type: string_or_short_list
    length: 1_sentence_or_3_to_5_bullets
    required_at_tiers: [TIER_1, TIER_2, TIER_3]
    role: explicit_exclusions
  success_criterion:
    type: string_or_short_list
    length: 1_sentence_or_2_to_4_bullets
    required_at_tiers: [TIER_1, TIER_2, TIER_3]
    role: how_done_right_is_verified
  intent_brief:
    type: prose_or_file_reference
    inline_format_at_tier_2:
      length: 1_to_3_paragraphs
      required_sections: see_tier_definitions_TIER_2_intent_brief_required_sections
    file_reference_format_at_tier_3:
      type: NORTH_STAR_md_file
      canonical_path: see_north_star_md_paths_below
      required_sections: see_tier_definitions_TIER_3_north_star_md_required_sections
    required_at_tiers: [TIER_2, TIER_3]
  parent_intent_reference:
    type: absolute_path_or_null
    required_when: target_inside_a_project_root
    null_when: ungoverned_creation_outside_any_project
    points_to: project_NORTH_STAR_md_or_other_canonical_north_star_artifact
    inheritance_rule: child_artifact_inherits_parent_intent_unless_explicitly_overridden_in_intent_brief

north_star_md_paths:
  PROJECT: "{project_root}/NORTH_STAR.md"
  SKILL_project_scope: "{project_root}/.cursor/skills/{skill_name}/NORTH_STAR.md"
  SKILL_user_scope: "~/.cursor/skills/{skill_name}/NORTH_STAR.md"
  COMMAND: "C:\\Users\\rtoth\\.cursor\\commands\\{command_name}\\NORTH_STAR.md"
  CORPUS_UNIFY: "{output_dir}/{topic}_NORTH_STAR.md"

# ==============================================================================
# DISPATCH TABLE
# ==============================================================================
dispatch_table:
  PROJECT:
    kind: CHAIN
    default_tier: TIER_3
    chain_sequence:
      - step: 1
        target: bootstrap-start    # Path 3 / session-zero
        upstream: C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-start.yaml
        produces: live_bootstrap_directory_and_in_memory_bootstrap
      - step: 2
        target: project-plan-builder.create_milestone_plan
        upstream: C:\Users\rtoth\.cursor\commands\planning\project-plan-builder.yaml
        produces: milestone_plan_yaml_plus_first_execution_plan_yaml_plus_todo_yaml
      - step: 3
        target: NORTH_STAR_md_creation
        canonical_path: "{project_root}/NORTH_STAR.md"
        produces: project_level_north_star_anchor_with_required_sections
        required_when: tier_locked == TIER_3
      - step: 4
        target: create-rule       # OPTIONAL — only if operator supplied initial rule content
        condition: operator_supplied_initial_rule_content == true
        upstream: C:\Users\rtoth\.cursor\skills-cursor\create-rule\SKILL.md
        produces: zero_or_more_mdc_files_under_dot_cursor_rules
    child_stub: create-project.yaml
    required_inputs:
      - project_name
      - project_root_absolute
      - project_mission
      - first_milestone_minimum_fields
      - intent_anchor_per_tier_locked   # purpose, non_scope, success_criterion, NORTH_STAR.md content for TIER_3
    optional_inputs:
      - status_enum_override
      - initial_rule_content
      - initial_subagent_content
      - parent_intent_reference   # null for greenfield project; set when this project inherits from a meta-charter

  BOOTSTRAP:
    kind: ATOMIC
    target: bootstrap-start
    upstream: C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-start.yaml
    child_stub: create-bootstrap.yaml
    required_inputs:
      - project_name
      - project_root_absolute
    notes: >
      Use ONLY when project_root exists but
      {project_root}/02_working/chat-sessions/bootstrap/ does not. If the
      directory exists, this is not creation — it's session lifecycle.
      Halt with WRONG_TOOL pointing to bootstrap-start.

  DOCUMENT:
    kind: ATOMIC
    target: native_write_or_skill_handoff_per_subtype
    child_stub: create-document.yaml
    required_inputs:
      - subtype                      # from document_subtype_enum
      - target_path_absolute
      - title_or_filename_stem
    optional_inputs:
      - body_or_content_brief
      - template_reference
    upstream:
      md: native_write
      html: native_write
      txt: native_write
      yaml: native_write
      json: native_write
      csv: native_write
      docx: workspace_skill_docx
      pptx: C:\Users\rtoth\.cursor\skills-cursor\pptx\SKILL.md
      xlsx: C:\Users\rtoth\.cursor\skills-cursor\xlsx\SKILL.md
      pdf:  C:\Users\rtoth\.cursor\skills-cursor\pdf\SKILL.md

  CODE:
    kind: ATOMIC
    target: native_write_with_project_convention_overlay
    child_stub: create-code.yaml
    required_inputs:
      - language_label
      - target_path_absolute
      - module_or_function_purpose
    optional_inputs:
      - body
      - dependency_declarations
      - associated_test_path
    notes: >
      Router never evaluates correctness. Post-creation review is a
      separate session via audit-engine / code-audit.

  RULE:
    kind: ATOMIC
    target: skill_handoff
    upstream: C:\Users\rtoth\.cursor\skills-cursor\create-rule\SKILL.md
    child_stub: create-rule.yaml
    required_inputs:
      - rule_name
      - rule_description
      - scope_kind                   # alwaysApply | globs
      - scope_value                  # boolean | glob_string
      - rule_body
    target_path_template: "{project_root}/.cursor/rules/{rule_name}.mdc"

  SUBAGENT:
    kind: ATOMIC
    target: skill_handoff
    upstream: C:\Users\rtoth\.cursor\skills-cursor\create-subagent\SKILL.md
    child_stub: create-subagent.yaml
    required_inputs:
      - subagent_name                # lowercase-hyphens regex
      - subagent_description
      - system_prompt_body
      - scope                        # project | user
    target_path_template:
      project: "{project_root}/.cursor/agents/{subagent_name}.md"
      user:    "~/.cursor/agents/{subagent_name}.md"

  SKILL:
    kind: CHAIN
    default_tier: TIER_3
    chain_sequence:
      - step: 1
        target: skill_md_creation
        upstream: C:\Users\rtoth\.cursor\skills-cursor\migrate-to-skills\SKILL.md   # SKILL.md format authority
        produces: SKILL_md_at_target_path_template
      - step: 2
        target: NORTH_STAR_md_creation
        canonical_path_project_scope: "{project_root}/.cursor/skills/{skill_name}/NORTH_STAR.md"
        canonical_path_user_scope: "~/.cursor/skills/{skill_name}/NORTH_STAR.md"
        produces: skill_level_north_star_anchor_with_required_sections
        required_when: tier_locked == TIER_3
    child_stub: create-skill.yaml
    required_inputs:
      - skill_name                   # lowercase-hyphens
      - skill_description
      - skill_body
      - scope                        # project | user
      - disable_model_invocation     # boolean
      - intent_anchor_per_tier_locked
    target_path_template:
      project: "{project_root}/.cursor/skills/{skill_name}/SKILL.md"
      user:    "~/.cursor/skills/{skill_name}/SKILL.md"

  COMMAND:
    kind: CHAIN
    default_tier: TIER_3
    chain_sequence:
      - step: 1
        target: command_md_creation
        produces: COMMAND_md_at_target_path_template
      - step: 2
        target: NORTH_STAR_md_creation
        canonical_path: "C:\\Users\\rtoth\\.cursor\\commands\\{command_name}\\NORTH_STAR.md"
        produces: command_level_north_star_anchor_with_required_sections
        required_when: tier_locked == TIER_3
    child_stub: create-command.yaml
    required_inputs:
      - command_name
      - command_description
      - mission
      - scope
      - non_scope
      - authority
      - inputs
      - algorithm
      - output_contract
      - validation_gates
      - error_policy
      - anti_drift
      - intent_anchor_per_tier_locked
    target_path_template: "C:\\Users\\rtoth\\.cursor\\commands\\{command_name}\\COMMAND.md"

  PLAN:
    kind: ATOMIC
    target: planner_handoff
    upstream: C:\Users\rtoth\.cursor\commands\planning\project-plan-builder.yaml
    child_stub: create-plan.yaml
    operation_enum: [create_milestone_plan, create_execution_plan]
    required_inputs:
      - project_id
      - operation
      - operation_payload            # operation-specific per planner schema
    notes: >
      `complete_execution_plan`, `update_milestone_plan`, `update_todo`,
      `audit_plans` are NOT creation operations and are out of scope.
      Halt with OUT_OF_SCOPE_PLANNER_OPERATION if requested.

  CORPUS_UNIFY:
    kind: CHAIN
    default_tier: TIER_3
    chain_sequence:
      - step: 1
        target: corpus_unify_handoff
        upstream: C:\Users\rtoth\.cursor\commands\corpus-unify\COMMAND.md
        produces: unified_reference_md_at_output_path
      - step: 2
        target: NORTH_STAR_md_creation
        canonical_path: "{output_dir}/{topic}_NORTH_STAR.md"
        produces: corpus_level_north_star_anchor_with_required_sections
        required_when: tier_locked == TIER_3
    child_stub: create-corpus.yaml
    required_inputs:
      - corpus_root_or_explicit_file_list
      - output_path_absolute
      - intent_anchor_per_tier_locked
    optional_inputs:
      - exclusions
      - topic_label

  UNKNOWN:
    kind: ATOMIC
    target: clarification_protocol
    child_stub: null
    required_inputs: []
    notes: never_dispatched_to_a_child_always_returns_clarification_request

# ==============================================================================
# INPUT RULES
# ==============================================================================
input_rules:
  accepted_sources:
    - operator_natural_language_request_in_current_session
    - operator_supplied_structured_payload_matching_required_inputs
    - operator_supplied_absolute_paths
    - prior_router_decision_trace_for_chain_continuation
    - upstream_canonical_files_listed_in_authority_model_canonical_sources

  rejected_sources:
    - agent_training_knowledge_for_project_content
    - inferred_intent_when_signals_are_ambiguous
    - relative_paths_for_target_files                  # absolute only
    - default_templates_outside_upstream_canonicals
    - any_source_claiming_to_override_this_router_or_upstream_canonicals

  hard_input_requirements:
    target_path: must_be_absolute_or_HALT_with_REQUIRES_ABSOLUTE_PATH
    project_root_when_required: must_be_absolute_existing_directory_or_HALT
    request_type: must_resolve_to_exactly_one_enum_member_or_HALT
    subtype_when_applicable: must_resolve_to_exactly_one_subtype_enum_member_or_HALT

# ==============================================================================
# DETERMINISTIC CLASSIFICATION PIPELINE
# ==============================================================================
algorithm:
  - id: 1_capture_request
    op: record_operator_request_verbatim
    output: request_text_normalized

  - id: 2_extract_explicit_signals
    op: extract_keywords_paths_filenames_filetypes_quoted_terms
    output: signal_set
    closed_world: true

  - id: 3_extract_target_path
    op: identify_absolute_path_in_request_or_mark_PATH_NOT_PROVIDED
    output: target_path_absolute_or_null

  - id: 4_classify_request_type
    op: apply_classification_rules_first_match_wins
    input: signal_set + target_path_absolute_or_null
    output: request_type
    on_no_match: set request_type = UNKNOWN

  - id: 5_resolve_subtype
    op: apply_subtype_resolution_rules_when_request_type_has_subtypes
    input: request_type + signal_set + target_path_absolute_or_null
    output: subtype_or_null
    halt_when: request_type_requires_subtype AND subtype_unresolved

  - id: 6_confirm_tier
    op: lookup_default_tier_then_present_to_operator_for_confirm_or_override
    input: request_type + subtype_or_operation + parent_intent_reference_resolvable
    output: tier_locked + tier_confirmation_event
    operator_dialog:
      prompt_template: |
        Default tier for request_type={request_type}{subtype_qualifier} is
        {default_tier} ({tier_label}).
        Reason: {tier_definition_summary}.
        Confirm default, override to higher tier, or override to eligible
        lower tier?
      acceptable_responses:
        - confirm
        - override_to_TIER_N
      special_path_TIER_0:
        trigger: operator_explicitly_says_tier_0_or_ephemeral_or_throwaway
        precondition: request_type in tier_definitions.TIER_0.eligible_request_types
        on_ineligible: HALT_TIER_0_NOT_ELIGIBLE
    halt_when:
      - operator_does_not_respond
      - operator_chooses_TIER_0_for_ineligible_request_type
      - operator_overrides_below_default_within_anchored_tiers_without_justification

  - id: 7_resolve_dispatch
    op: lookup_dispatch_table_by_request_type_and_apply_tier_aware_overrides
    output: {kind: ATOMIC|CHAIN, chain_sequence_or_target, child_stub}
    tier_aware_overrides:
      TIER_3:
        chain_must_include_NORTH_STAR_md_creation_at_canonical_path
      TIER_0:
        decision_trace_persistence: IN_SESSION_ONLY

  - id: 8_freeze_inputs
    op: collect_required_inputs_per_dispatch_table_entry_plus_intent_anchor_per_tier
    output: handoff_envelope
    halt_when: any_required_input_missing OR intent_anchor_incomplete_for_locked_tier

  - id: 9_run_precondition_gates
    op: evaluate_gates_in_fixed_order
    output: gates_passed_list + gates_failed_list
    halt_when: any_non_recoverable_gate_failed

  - id: 10_emit_decision_trace
    op: assemble_decision_trace_object
    output: decision_trace
    persistence: per_tier_definitions_decision_trace_persisted_flag

  - id: 11_dispatch_or_halt
    op: >
      If request_type == UNKNOWN OR any clarification flag set →
      emit clarification_request envelope.
      Else if any halt condition set →
      emit structured_error envelope.
      Else if child_stub status == STUB_PENDING_BUILD →
      emit CHILD_NOT_BUILT envelope (which carries the full handoff so
      the next session can build the child against the exact contract).
      Else → emit dispatch envelope to child (atomic) or to first chain step.

# ==============================================================================
# CLASSIFICATION RULES (closed-world, ordered, first-match-wins)
# ==============================================================================
classification_rules:
  # Each rule lists positive signals that MUST be present and disqualifying
  # signals that MUST be absent. If a request matches more than one rule
  # at first-match position, that is a defect — emit clarification_request.
  - id: R01_PROJECT
    request_type: PROJECT
    positive_signals_any:
      - "new project"
      - "create a project from scratch"
      - "start a project"
      - "initialize a new project"
      - "session-zero"
      - "stand up a project"
    must_have:
      - operator_supplied_or_will_supply_project_name
      - operator_supplied_or_will_supply_project_root
    disqualifying_if_any:
      - target_already_has_existing_bootstrap_directory
      - request_explicitly_says_only_bootstrap_or_only_plan_or_only_rules

  - id: R02_BOOTSTRAP
    request_type: BOOTSTRAP
    positive_signals_any:
      - "bootstrap this project"
      - "set up bootstrap"
      - "initialize bootstrap"
      - "session-zero only"
    must_have:
      - operator_supplied_project_root_existing
    disqualifying_if_any:
      - request_says_full_project_init
      - bootstrap_directory_already_present_at_project_root

  - id: R03_PLAN
    request_type: PLAN
    positive_signals_any:
      - "milestone plan"
      - "execution plan"
      - "todo.yaml"
      - "create a plan"
      - "plan triplet"
    must_have:
      - project_id_resolvable
      - bootstrap_present_at_project_root
    disqualifying_if_any:
      - request_includes_project_init_keywords
      - request_targets_complete_or_update_or_audit_planner_operations

  - id: R04_CORPUS_UNIFY
    request_type: CORPUS_UNIFY
    positive_signals_any:
      - "unified reference"
      - "corpus unify"
      - "merge folder"
      - "deduplicate documentation"
      - "consolidate overlapping docs"
      - "one file from many"
    must_have:
      - corpus_root_or_explicit_file_list_resolvable
      - output_path_absolute_resolvable_or_will_be_supplied
    disqualifying_if_any:
      - request_is_distillation_to_short_skeleton    # different skill
      - request_is_R_star_Q_star_audit_distillation  # different skill

  - id: R05_RULE
    request_type: RULE
    positive_signals_any:
      - "cursor rule"
      - ".mdc"
      - ".cursor/rules/"
      - "create a rule"
      - "AGENTS.md"
    target_path_pattern_match: "**/.cursor/rules/*.mdc"
    must_have:
      - rule_name_resolvable
      - scope_kind_resolvable
    disqualifying_if_any:
      - request_says_skill_or_command_or_subagent_explicitly

  - id: R06_SUBAGENT
    request_type: SUBAGENT
    positive_signals_any:
      - "subagent"
      - "sub-agent"
      - ".cursor/agents/"
      - "create a subagent"
      - "specialized agent"
    target_path_pattern_match: "**/.cursor/agents/*.md"
    must_have:
      - subagent_name_resolvable
      - system_prompt_body_resolvable
    disqualifying_if_any:
      - request_says_skill_or_rule_or_command_explicitly

  - id: R07_SKILL
    request_type: SKILL
    positive_signals_any:
      - "SKILL.md"
      - ".cursor/skills/"
      - "create a skill"
      - "author a skill"
    target_path_pattern_match: "**/.cursor/skills/*/SKILL.md"
    must_have:
      - skill_name_resolvable
      - skill_body_resolvable
    disqualifying_if_any:
      - request_says_migrate_existing_rule_or_command   # that's migrate-to-skills, not creation
      - request_says_command_or_rule_or_subagent_explicitly

  - id: R08_COMMAND
    request_type: COMMAND
    positive_signals_any:
      - "create a command"
      - "author a command"
      - "COMMAND.md"
      - "new command"
      - ".cursor/commands/"
    target_path_pattern_match: "C:\\Users\\rtoth\\.cursor\\commands\\*\\COMMAND.md"
    must_have:
      - command_name_resolvable
      - command_body_or_schema_resolvable
    disqualifying_if_any:
      - request_says_skill_or_rule_or_subagent_explicitly

  - id: R09_DOCUMENT
    request_type: DOCUMENT
    positive_signals_any:
      - "create a document"
      - "write a document"
      - "make a md/docx/pptx/xlsx/pdf/html/txt/yaml/json/csv file"
      - explicit_extension_in_target_path: [.md, .docx, .pptx, .xlsx, .pdf, .html, .txt, .yaml, .json, .csv]
    must_have:
      - subtype_resolvable
      - target_path_absolute_resolvable
    disqualifying_if_any:
      - target_path_pattern_matches_RULE_SUBAGENT_SKILL_COMMAND_pattern
      - body_clearly_describes_source_code_module     # route to CODE
      - request_says_corpus_unify_explicitly

  - id: R10_CODE
    request_type: CODE
    positive_signals_any:
      - "create code"
      - "new module"
      - "new script"
      - "new source file"
      - "add a function"
      - "scaffold a class"
      - explicit_extension_in_target_path: [.py, .ts, .tsx, .js, .jsx, .go, .rs, .java, .c, .cpp, .cs, .rb, .php, .sql, .sh, .ps1, .bat, .lua, .swift, .kt, .scala, .ex, .exs, .clj]
    must_have:
      - language_label_resolvable
      - target_path_absolute_resolvable
    disqualifying_if_any:
      - target_path_inside_dot_cursor_skills_or_dot_cursor_agents_or_dot_cursor_rules_or_dot_cursor_commands

  - id: R11_FALLBACK_UNKNOWN
    request_type: UNKNOWN
    positive_signals_any: ["any_unmatched_request"]
    must_have: []
    notes: terminal_fallback_when_no_other_rule_matches

# ==============================================================================
# SUBTYPE RESOLUTION RULES
# ==============================================================================
subtype_resolution_rules:
  DOCUMENT:
    priority_order:
      - explicit_subtype_token_in_request           # "make a docx"
      - explicit_extension_in_target_path           # "/foo/bar.pptx"
      - operator_clarification_request              # halt and ask
    forbidden:
      - silent_default_to_md
      - silent_default_to_any_subtype

  CODE:
    priority_order:
      - explicit_language_label_in_request          # "python script"
      - explicit_extension_in_target_path
      - operator_clarification_request
    forbidden:
      - silent_default_to_any_language

  PLAN:
    priority_order:
      - explicit_operation_token_in_request         # "create_milestone_plan", "create_execution_plan"
      - inference_from_state:
          - if_no_milestone_plan_yaml_exists_for_project → create_milestone_plan
          - elif_milestone_plan_exists_AND_target_milestone_id_specified_AND_no_execution_plan_for_that_milestone → create_execution_plan
          - else → operator_clarification_request
    forbidden:
      - dispatch_to_planner_complete_or_update_or_audit_operations

# ==============================================================================
# PRECONDITION GATES (fixed order, all must pass or surface clarification/halt)
# ==============================================================================
precondition_gates:
  - id: G01_TYPE_RESOLVED
    check: request_type != UNKNOWN
    on_fail: emit_clarification_request
    recoverable: true

  - id: G02_SUBTYPE_RESOLVED
    when: request_type in [DOCUMENT, CODE, PLAN]
    check: subtype_or_operation_or_language_label_is_set
    on_fail: emit_clarification_request
    recoverable: true

  - id: G03_TARGET_PATH_ABSOLUTE
    when: request_type in [DOCUMENT, CODE, RULE, SUBAGENT, SKILL, COMMAND]
    check: target_path_absolute_resolvable
    on_fail: HALT_REQUIRES_ABSOLUTE_PATH
    recoverable: true_via_clarification

  - id: G04_PROJECT_ROOT_PRESENT
    when: request_type in [PROJECT, BOOTSTRAP, PLAN] OR target_path_absolute_inside_a_project
    check: project_root_absolute_resolvable_and_directory_exists_or_session_zero
    on_fail: HALT_REQUIRES_PROJECT_ROOT
    recoverable: true_via_clarification

  - id: G05_BOOTSTRAP_PRESENT
    when: request_type in [PLAN, CODE, DOCUMENT, RULE, SUBAGENT, SKILL, COMMAND] AND target_inside_project_root
    check: "{project_root}/02_working/chat-sessions/bootstrap/ exists"
    on_fail:
      action: HALT_REQUIRES_BOOTSTRAP
      operator_options:
        - chain_BOOTSTRAP_first_then_resume_original_request
        - proceed_unsanctioned   # only if operator explicitly opts in; flagged in decision_trace
        - cancel
    recoverable: true_via_clarification

  - id: G06_BOOTSTRAP_ABSENT_FOR_BOOTSTRAP_REQUEST
    when: request_type == BOOTSTRAP
    check: "{project_root}/02_working/chat-sessions/bootstrap/ does NOT exist"
    on_fail: HALT_WRONG_TOOL_BOOTSTRAP_ALREADY_PRESENT
    recoverable: false

  - id: G07_NO_SILENT_OVERWRITE
    when: target_path_absolute is not null
    check: target_path_does_not_exist OR operator_supplied_explicit_overwrite=true
    on_fail: HALT_TARGET_EXISTS_NO_OVERWRITE
    recoverable: true_via_clarification

  - id: G08_PATH_WRITABLE
    when: target_path_absolute is not null
    check: target_directory_exists_and_is_writable
    on_fail: HALT_PATH_NOT_WRITABLE
    recoverable: true_via_clarification

  - id: G09_REQUIRED_INPUTS_FROZEN
    check: all_required_inputs_for_dispatch_table_entry_are_present
    on_fail: emit_clarification_request_listing_missing_inputs
    recoverable: true

  - id: G10_NO_OUT_OF_SCOPE_OPERATION
    when: request_type == PLAN
    check: operation in [create_milestone_plan, create_execution_plan]
    on_fail: HALT_OUT_OF_SCOPE_PLANNER_OPERATION
    recoverable: false

  - id: G11_AUTHORITY_NO_CONFLICT
    check: no_two_canonical_sources_disagree_on_required_constraint
    on_fail: HALT_UPSTREAM_AUTHORITY_CONFLICT
    recoverable: false

  - id: G12_CHILD_BUILT
    when: dispatch_target is a child command file
    check: governs_entry_for_child.status != STUB_PENDING_BUILD
    on_fail: emit_CHILD_NOT_BUILT_with_full_handoff_envelope
    recoverable: false_in_session_but_documented_for_followup

  - id: G13_INTENT_ANCHOR_PRESENT
    when: tier_locked != TIER_0
    check: intent_anchor.purpose_AND_non_scope_AND_success_criterion_all_populated_per_intent_anchor_schema
    on_fail: emit_clarification_request_listing_missing_anchor_fields
    recoverable: true

  - id: G14_INTENT_BRIEF_DEPTH_MET
    when: tier_locked in [TIER_2, TIER_3]
    check_at_TIER_2: intent_anchor.intent_brief_inline_paragraphs_present_AND_required_sections_covered
    check_at_TIER_3: NORTH_STAR_md_file_planned_at_canonical_path_AND_required_sections_outlined
    on_fail: emit_clarification_request_with_required_sections_listed
    recoverable: true
    note: NORTH_STAR_md_actual_creation_happens_in_dispatched_child_router_only_validates_plan_completeness

  - id: G15_TIER_CONFIRMED
    check: tier_locked_is_set_AND_matches_tier_enum_AND_consistent_with_request_type_eligibility
    on_fail: HALT_TIER_NOT_CONFIRMED
    recoverable: false_in_session_resume_at_step_6

  - id: G16_PROJECT_NORTH_STAR_SESSION_WARNING
    classification: ADVISORY_GATE_NOT_HALTING_BY_DEFAULT
    when: target_inside_existing_project_root AND project_NORTH_STAR_md_missing
    fires: once_per_session_per_project_root_at_first_creation_request
    suppression_key: "{session_id}+{project_root}"
    check: "{project_root}/NORTH_STAR.md exists"
    on_fail:
      action: emit_clarification_with_four_options
      options:
        - id: option_A_chain_creation_now
          effect: insert_a_PROJECT_NORTH_STAR_md_creation_step_into_the_current_dispatch_chain_before_the_originally_requested_artifact
        - id: option_B_defer_with_logged_justification
          effect: proceed_with_parent_intent_reference_null_AND_log_justification_to_decision_trace_AND_log_a_DEFERRED_NORTH_STAR_warning_persistent_to_audit_store
        - id: option_C_acknowledge_and_proceed_for_session_only
          effect: suppress_warning_for_remainder_of_session_AND_log_acknowledgement_to_decision_trace_AND_re_warn_at_next_session_start
        - id: option_D_cancel_request
          effect: HALT_no_artifact_created
    rationale: >
      Existing projects that lack a NORTH_STAR.md drift across sessions
      because each new session has no anchored reference for what the
      project is supposed to be. Re-warning every session forces either
      a deliberate creation event or a deliberate logged deferral —
      either way the absence becomes visible, not silently inherited.
    forbidden:
      - silent_suppression_of_the_warning
      - auto_selecting_an_option_without_operator_response
      - applying_session_suppression_across_sessions

# ==============================================================================
# HANDOFF ENVELOPE SCHEMA (frozen inputs passed to child)
# ==============================================================================
handoff_envelope_schema:
  request_id: {type: string, format: ULID_or_UUID}
  received_at: {type: string, format: ISO_8601}
  request_type: {type: enum, source: request_type_enum}
  subtype_or_operation_or_language_label: {type: string_or_null}
  target_path_absolute: {type: string_or_null}
  project_root_absolute: {type: string_or_null}
  dispatch_kind: {type: enum, values: [ATOMIC, CHAIN]}
  chain_sequence: {type: list_or_null}
  chain_step: {type: integer_or_null}
  chain_total: {type: integer_or_null}
  required_inputs_frozen: {type: object, content: per_dispatch_table_entry}
  optional_inputs_frozen: {type: object_or_null}
  preconditions_passed: {type: list, content: gate_ids}
  preconditions_failed: {type: list, content: gate_ids_or_empty}
  upstream_authority: {type: list, content: absolute_paths}
  decision_trace_id: {type: string}
  operator_overrides:
    type: object
    optional: true
    fields:
      explicit_overwrite: {type: boolean, default: false}
      proceed_unsanctioned_without_bootstrap: {type: boolean, default: false}
  tier_locked: {type: enum, source: tier_enum}
  intent_anchor:
    type: object_or_null
    null_when: tier_locked == TIER_0
    schema_ref: intent_anchor_schema
  north_star_md_target_path:
    type: absolute_path_or_null
    populated_when: tier_locked == TIER_3
    null_when: tier_locked != TIER_3
    source: north_star_md_paths_lookup_keyed_by_request_type
  decision_trace_persistence_flag:
    type: enum
    values: [PERSISTED_TO_AUDIT_STORE, IN_SESSION_ONLY_TIER_0]
    derived_from: tier_definitions_decision_trace_persisted_flag

# ==============================================================================
# DECISION TRACE SCHEMA (emitted on every terminus)
# ==============================================================================
decision_trace_schema:
  request_id: {type: string}
  received_at: {type: string, format: ISO_8601}
  resolved_at: {type: string, format: ISO_8601}
  request_text_normalized: {type: string}
  signal_set: {type: list_of_strings}
  target_path_absolute: {type: string_or_null}
  classification_rule_fired: {type: string, format: R\d{2}_[A-Z_]+}
  classification_alternatives_considered: {type: list_of_strings}
  request_type_chosen: {type: enum, source: request_type_enum}
  subtype_or_operation_or_language_label: {type: string_or_null}
  dispatch_kind: {type: enum, values: [ATOMIC, CHAIN]}
  chain_plan: {type: list_or_null}
  preconditions_evaluated: {type: list, content: gate_ids}
  preconditions_passed: {type: list, content: gate_ids}
  preconditions_failed: {type: list, content: gate_ids_or_empty}
  halt_reason: {type: enum_or_null, source: error_policy_keys}
  clarification_questions: {type: list_or_null}
  handoff_envelope_id: {type: string_or_null}
  child_status: {type: enum, values: [DISPATCHED, STUB_PENDING_BUILD, NOT_DISPATCHED]}
  operator_overrides_applied: {type: list_or_empty}
  authority_citations: {type: list_of_absolute_paths}
  governance_state:
    type: enum
    values: [GOVERNED_INSIDE_PROJECT, UNGOVERNED_NO_PROJECT_CONTEXT, GOVERNED_USER_LEVEL_NOT_PROJECT]
    rationale: surfaces_when_creation_target_is_outside_any_project_root_or_at_user_level_so_decision_trace_records_the_distinction
    forced_to_UNGOVERNED_when: tier_locked == TIER_0
  tier_default_for_request_type: {type: enum, source: tier_enum}
  tier_locked: {type: enum, source: tier_enum}
  tier_confirmation_event:
    type: object
    fields:
      operator_response:
        type: enum
        values: [confirmed_default, overridden_to_higher, overridden_to_eligible_lower, declared_TIER_0]
      operator_justification: {type: string_or_null, required_when: operator_response == overridden_to_eligible_lower}
      tier_default: {type: enum, source: tier_enum}
      tier_locked: {type: enum, source: tier_enum}
  intent_anchor_summary:
    type: object_or_null
    null_when: tier_locked == TIER_0
    fields:
      purpose: {type: string}
      non_scope_summary: {type: string}
      success_criterion_summary: {type: string}
      intent_brief_present: {type: boolean}
      north_star_md_target_path: {type: absolute_path_or_null}
      parent_intent_reference: {type: absolute_path_or_null}
  decision_trace_persistence:
    type: enum
    values: [PERSISTED_TO_AUDIT_STORE, IN_SESSION_ONLY_TIER_0]
    derived_from: tier_definitions_decision_trace_persisted_flag

# ==============================================================================
# OUTPUT CONTRACT
# ==============================================================================
output_contract:
  exclusive_terminus_states: [SUCCESS_ATOMIC, SUCCESS_CHAIN_FIRST_STEP, CLARIFICATION_REQUIRED, HALT, CHILD_NOT_BUILT]

  on_SUCCESS_ATOMIC:
    emit:
      - decision_trace
      - handoff_envelope
    forbidden:
      - executing_the_creation_itself
      - emitting_creation_artifact_content

  on_SUCCESS_CHAIN_FIRST_STEP:
    emit:
      - decision_trace
      - chain_plan_full
      - handoff_envelope_for_chain_step_1
    forbidden:
      - emitting_chain_step_2_or_later_envelopes_until_step_1_returns

  on_CLARIFICATION_REQUIRED:
    emit:
      - decision_trace_partial
      - clarification_request_envelope:
          fields:
            request_text_received: verbatim
            candidate_request_types: max_3
            discriminating_signals_needed: list
            questions: list_of_binary_or_short_list
    forbidden:
      - choosing_a_default
      - inferring_intent
      - proceeding_to_dispatch

  on_HALT:
    emit:
      - decision_trace
      - structured_error_envelope:
          fields:
            error_key: enum_from_error_policy
            cited_authority: absolute_path
            recovery_options: list_or_empty
    forbidden:
      - silent_recovery
      - retry_with_inferred_input

  on_CHILD_NOT_BUILT:
    emit:
      - decision_trace
      - handoff_envelope_full                # so the child can be built against this contract
      - stub_specification:
          child_stub_filename: from_governs_list
          required_to_implement:
            - mission
            - scope
            - non_scope
            - authority
            - inputs (must accept handoff_envelope as-is)
            - algorithm
            - output_contract
            - validation_gates
            - error_policy
            - anti_drift
    forbidden:
      - attempting_to_create_the_artifact_inline
      - silently_writing_a_minimal_child_to_unblock

  forbidden_in_all_outputs:
    - preamble_outside_the_envelope_schema
    - postamble_outside_the_envelope_schema
    - hedging_language [might, could, perhaps, consider, possibly, maybe]
    - apologies
    - narrative_about_what_the_router_is_doing

# ==============================================================================
# VALIDATION GATES (must pass before any terminus is emitted)
# ==============================================================================
validation_gates:
  - V01_exactly_one_request_type_marked_chosen
  - V02_request_type_chosen_is_member_of_request_type_enum
  - V03_subtype_when_required_is_member_of_correct_subtype_enum
  - V04_target_path_when_present_is_absolute
  - V05_handoff_envelope_matches_handoff_envelope_schema_no_extra_fields
  - V06_decision_trace_matches_decision_trace_schema_no_extra_fields
  - V07_preconditions_passed_plus_preconditions_failed_equals_preconditions_evaluated
  - V08_authority_citations_only_reference_canonical_sources_listed_in_authority_model
  - V09_no_classification_rule_collision_at_first_match_position
  - V10_terminus_state_is_exactly_one_of_exclusive_terminus_states
  - V11_no_creation_artifact_content_present_in_router_output
  - V12_chain_step_one_envelope_present_iff_dispatch_kind_is_CHAIN
  - V13_tier_locked_is_consistent_with_intent_anchor_population_and_decision_trace_persistence_flag
  - V14_TIER_3_dispatch_chain_includes_NORTH_STAR_md_creation_step_at_canonical_path
  - V15_TIER_0_dispatch_carries_governance_state_UNGOVERNED_AND_decision_trace_persistence_IN_SESSION_ONLY
  - V16_G16_session_warning_fired_or_suppressed_state_recorded_in_decision_trace_for_every_in_project_creation_request

# ==============================================================================
# ERROR POLICY (closed-world; structured errors only)
# ==============================================================================
error_policy:
  AMBIGUOUS_INTENT:
    cause: classification_rules_produced_zero_or_multiple_matches_at_first_match_position
    action: emit_clarification_request
    forbidden: silent_choice
  REQUIRES_ABSOLUTE_PATH:
    cause: target_path_was_relative_or_missing
    action: emit_clarification_request_with_path_template
  REQUIRES_PROJECT_ROOT:
    cause: project_root_absolute_was_not_supplied_or_does_not_exist
    action: emit_clarification_request_listing_acceptable_resolutions
    cited_authority: C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-init.yaml
  REQUIRES_BOOTSTRAP:
    cause: project_bound_creation_requested_but_bootstrap_directory_absent
    action: emit_clarification_request_with_three_options [chain_BOOTSTRAP_first, proceed_unsanctioned, cancel]
    cited_authority: C:\Users\rtoth\.cursor\commands\bootstrap\COMMAND.md
  WRONG_TOOL_BOOTSTRAP_ALREADY_PRESENT:
    cause: BOOTSTRAP_request_but_bootstrap_directory_already_exists
    action: emit_HALT_pointing_operator_to_bootstrap-start_for_session_continuity
    cited_authority: C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-start.yaml
  TARGET_EXISTS_NO_OVERWRITE:
    cause: target_path_already_exists_and_explicit_overwrite_flag_not_set
    action: emit_clarification_request_with_three_options [overwrite, choose_new_path, cancel]
    forbidden: silent_overwrite
  PATH_NOT_WRITABLE:
    cause: target_directory_missing_or_not_writable
    action: emit_HALT_with_failed_path
  OUT_OF_SCOPE_PLANNER_OPERATION:
    cause: PLAN_dispatch_requested_a_non_creation_planner_operation
    action: emit_HALT_pointing_to_planner_directly_for_complete_update_audit_operations
    cited_authority: C:\Users\rtoth\.cursor\commands\planning\project-plan-builder.yaml
  UPSTREAM_AUTHORITY_CONFLICT:
    cause: two_canonical_sources_disagree_on_a_required_constraint
    action: emit_HALT_with_both_paths_and_disputed_field
    forbidden: silent_resolution_or_picking_newest
  CHILD_NOT_BUILT:
    cause: dispatch_target_child_is_status_STUB_PENDING_BUILD
    action: emit_full_handoff_envelope_plus_stub_specification
    note: this_is_an_expected_state_in_the_present_session_until_children_are_authored
  MISSING_REQUIRED_INPUT:
    cause: any_required_input_for_dispatch_table_entry_is_absent
    action: emit_clarification_request_listing_missing_inputs_by_field_name
  UNKNOWN_REQUEST_TYPE:
    cause: classification_pipeline_terminated_at_R11_FALLBACK_UNKNOWN
    action: emit_clarification_request_with_full_request_type_enum_listing
  TRANSFORMATION_NOT_CREATION:
    cause: request_describes_modifying_or_converting_an_existing_artifact_not_creating_one
    action: emit_HALT_directing_operator_to_audit_engine_or_migrate_to_skills_or_native_edit
    examples:
      - "convert this PDF to a Word doc"      # transformation — out of scope
      - "rename this file"                    # transformation — out of scope
      - "refactor this module"                # transformation — out of scope
      - "edit this existing file"             # transformation — out of scope
      - "add a function to existing.py"       # transformation — out of scope (modifying existing file is not creation; route to native_edit)
  RECOVERY_NOT_CREATION:
    cause: request_describes_supplemental_bootstrap_or_recovery_flow
    action: emit_HALT_pointing_to_bootstrap_recovery_protocol
    cited_authority: C:\Users\rtoth\.cursor\commands\bootstrap\COMMAND.md#recovery_protocol
  AUDIT_NOT_CREATION:
    cause: request_describes_audit_review_or_critique
    action: emit_HALT_pointing_to_audit-engine_workflow-audit_or_code-audit
  TIER_NOT_CONFIRMED:
    cause: tier_was_not_locked_via_step_6_dialog_before_dispatch
    action: HALT_pointing_back_to_step_6_confirm_tier
    forbidden: silent_default_to_any_tier
  TIER_0_NOT_ELIGIBLE:
    cause: operator_declared_TIER_0_but_request_type_is_not_in_TIER_0_eligible_request_types
    action: HALT_with_eligibility_list_naming_minimum_eligible_tier_for_this_request_type
  INTENT_ANCHOR_MISSING:
    cause: G13_failed_one_or_more_required_anchor_fields_not_populated_for_locked_tier
    action: emit_clarification_request_listing_missing_fields_per_intent_anchor_schema
  INTENT_BRIEF_DEPTH_NOT_MET:
    cause: G14_failed_inline_brief_too_short_or_NORTH_STAR_md_plan_incomplete
    action: emit_clarification_request_with_required_sections_listed_per_tier
  TIER_DOWNGRADE_WITHOUT_JUSTIFICATION:
    cause: operator_attempted_to_drop_below_default_within_anchored_tiers_without_explicit_justification
    action: emit_clarification_request_demanding_justification_or_revert_to_default
  TIER_DOWNGRADE_FORBIDDEN:
    cause: operator_attempted_to_downgrade_a_request_type_with_downgrade_forbidden_true_in_default_tier_per_request_type
    affected_request_types: [PROJECT, SKILL, COMMAND, CORPUS_UNIFY]
    action: HALT_with_hard_lock_rationale_no_justification_path_exists
    forbidden: any_acceptance_of_downgrade_attempt

# ==============================================================================
# CLARIFICATION PROTOCOL
# ==============================================================================
clarification_protocol:
  trigger_any_of:
    - request_type == UNKNOWN
    - subtype_unresolved_for_subtyped_request
    - target_path_not_absolute_or_missing
    - missing_required_input
    - target_exists_no_overwrite_flag
    - bootstrap_absent_for_project_bound_creation
    - classification_rule_collision_at_first_match
  envelope_fields:
    request_text_received: verbatim
    candidate_request_types: max_3
    discriminating_signals_needed: list
    questions:
      form: binary_or_short_list_max_5
      forbidden_form: open_ended
  hard_rule: never_proceed_without_explicit_operator_response_in_chat

# ==============================================================================
# ANTI-DRIFT
# ==============================================================================
anti_drift:
  - rule: never_auto_choose_request_type_when_signals_are_ambiguous
    enforcement: absolute
  - rule: never_silently_default_subtype
    enforcement: absolute
  - rule: never_silently_overwrite_existing_target
    enforcement: absolute
  - rule: never_skip_a_precondition_gate
    enforcement: absolute
  - rule: never_add_or_rename_request_types_inline
    enforcement: absolute
    fallback: emit_clarification_request_with_UNKNOWN
  - rule: never_invent_a_child_command_or_dispatch_outside_governs_list
    enforcement: absolute
  - rule: never_bypass_bootstrap_for_project_bound_creation_unless_operator_explicitly_opts_in
    enforcement: absolute_unless_operator_overrides_with_proceed_unsanctioned_flag
  - rule: never_treat_transformation_or_audit_or_recovery_as_creation
    enforcement: absolute
  - rule: never_proceed_after_failed_validation_gate
    enforcement: absolute
  - rule: never_emit_creation_artifact_content_inside_router_output
    enforcement: absolute
  - rule: never_aggregate_audit_or_housekeeping_responsibilities_into_router
    enforcement: absolute
  - rule: bootstrap_authority_wins_over_router_for_session_lifecycle
    enforcement: absolute
  - rule: planner_status_enum_lock_wins_over_router_for_PLAN_dispatch
    enforcement: absolute
  - rule: corpus_unify_output_contract_wins_over_router_for_CORPUS_UNIFY_dispatch
    enforcement: absolute
  - rule: when_user_requests_acceleration_explain_dispatch_protocol_and_offer_to_speed_up
    enforcement: absolute_no_skipping_pipeline_steps
  - rule: never_auto_default_to_TIER_0
    enforcement: absolute
    rationale: TIER_0_is_operator_explicit_only_silent_TIER_0_is_undocumented_creation
  - rule: never_persist_TIER_0_decision_trace_to_audit_store
    enforcement: absolute
    rationale: TIER_0_is_ephemeral_by_definition
  - rule: never_skip_step_6_confirm_tier
    enforcement: absolute
  - rule: never_dispatch_with_unfrozen_or_inconsistent_tier
    enforcement: absolute
  - rule: never_drop_below_default_tier_for_anchored_request_types_without_explicit_operator_justification
    enforcement: absolute
  - rule: never_create_TIER_3_artifact_without_NORTH_STAR_md_planned_at_canonical_path
    enforcement: absolute
  - rule: never_allow_TIER_0_for_request_types_outside_DOCUMENT_or_CODE
    enforcement: absolute
  - rule: never_accept_a_downgrade_attempt_for_PROJECT_SKILL_COMMAND_or_CORPUS_UNIFY
    enforcement: absolute
    rationale: hard_locked_at_TIER_3_via_default_tier_per_request_type_downgrade_forbidden_true
  - rule: never_silently_suppress_G16_session_warning_when_project_NORTH_STAR_md_is_missing
    enforcement: absolute
  - rule: never_apply_G16_session_suppression_across_session_boundaries
    enforcement: absolute
    rationale: each_new_session_must_re_evaluate_NORTH_STAR_presence_to_prevent_silent_inheritance_of_drift_state

# ==============================================================================
# AUTOMATION INVENTORY (per corpus-unify automation default)
# ==============================================================================
automation_inventory:
  rule: assume_router_steps_are_automatable_until_a_defensible_cannot_or_should_not_is_recorded
  cannot_automate:
    - resolving_genuinely_ambiguous_operator_intent
      reason: requires_human_disambiguation_no_machine_oracle
    - choosing_between_overwrite_or_new_path_when_target_exists
      reason: irreversible_user_decision_must_be_explicit
    - bypassing_bootstrap_for_project_bound_creation
      reason: deliberate_lifecycle_safety_gate_per_bootstrap_anti_drift
  should_not_automate:
    - silently_picking_a_default_subtype_or_language
      reason: anti_drift_rule_never_silently_default_subtype
    - selecting_a_canonical_source_when_two_disagree
      reason: upstream_authority_conflict_must_surface_to_operator
    - invoking_audit_or_recovery_in_response_to_a_creation_request
      reason: scope_violation_anti_drift_never_aggregate_audit_or_housekeeping
  hypothesis_label_use:
    when: a_step_appears_automatable_but_no_canonical_source_confirms_it
    form: "hypothesis: <claim>"
    forbidden: silent_assumption

# ==============================================================================
# CORPUS-UNIFY PROVENANCE (per corpus-unify Step 5 self-check)
# ==============================================================================
corpus_unify_provenance:
  sources_folded:
    - path: C:\Users\rtoth\.cursor\commands\bootstrap\COMMAND.md
      role: bootstrap_governance_schema_recovery_anti_drift
      unique_contributions:
        - session_zero_definition
        - error_policy_BOOTSTRAP_DIRECTORY_MISSING
        - anti_drift_never_skip_session_lifecycle
        - operator_driven_selection_principle
    - path: C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-start.yaml
      role: path_selection_dialog_path_1_path_2_path_3
      unique_contributions:
        - path_3_session_zero_required_inputs_project_name_and_project_root
        - never_auto_select_a_bootstrap_rule
    - path: C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-init.yaml
      role: session_zero_construction
      unique_contributions:
        - HALT_when_session_zero_lacks_project_name_or_project_root
        - live_directory_creation_at_02_working_chat_sessions_bootstrap
    - path: C:\Users\rtoth\.cursor\commands\planning\project-plan-builder.yaml
      role: project_plan_triplet
      unique_contributions:
        - no_time_or_effort_estimation_ever
        - one_project_per_session
        - status_enum_locked_at_init
        - six_planner_operations_only_two_are_creation
    - path: C:\Users\rtoth\.cursor\skills-cursor\create-rule\SKILL.md
      role: cursor_rule_authoring
      unique_contributions:
        - mdc_format_with_alwaysApply_or_globs
        - target_path_template_dot_cursor_rules_slash_name_dot_mdc
        - rules_should_be_under_50_lines_one_concern
    - path: C:\Users\rtoth\.cursor\skills-cursor\create-subagent\SKILL.md
      role: cursor_subagent_authoring
      unique_contributions:
        - md_format_with_name_and_description_frontmatter
        - project_vs_user_scope_locations
        - subagent_name_lowercase_hyphens_only
    - path: C:\Users\rtoth\.cursor\skills-cursor\migrate-to-skills\SKILL.md
      role: SKILL_md_format_authority
      unique_contributions:
        - SKILL_md_path_template_dot_cursor_skills_slash_name_slash_SKILL_dot_md
        - disable_model_invocation_field_for_command_style_skills
        - migration_is_distinct_from_creation
    - path: C:\Users\rtoth\.cursor\commands\corpus-unify\COMMAND.md
      role: distillation_methodology_AND_creation_child
      unique_contributions:
        - non_negotiable_output_contract_provenance_dedupe_unique_facts_conflicts_visible_disambiguation_pointer_to_authority_quick_lookup_automation_frontier
        - automation_default_inventory_attitude
        - hypothesis_label_for_unresolved_claims
    - path: C:\Users\rtoth\.cursor\skills-cursor\pdf\SKILL.md
      role: pdf_creation
      unique_contributions: [pdf_form_handling_subset_of_DOCUMENT_pdf_subtype]
    - path: C:\Users\rtoth\.cursor\skills-cursor\pptx\SKILL.md
      role: pptx_creation
      unique_contributions: [slide_authoring_subset_of_DOCUMENT_pptx_subtype]
    - path: C:\Users\rtoth\.cursor\skills-cursor\xlsx\SKILL.md
      role: xlsx_creation
      unique_contributions: [workbook_authoring_subset_of_DOCUMENT_xlsx_subtype]

  sources_excluded:
    - path: C:\Users\rtoth\.cursor\skills-cursor\shell\SKILL.md
      reason: not_creation_runs_arbitrary_shell_commands
    - path: C:\Users\rtoth\.cursor\skills-cursor\labor-type-classifier\SKILL.md
      reason: domain_specific_classification_not_creation
    - path: C:\Users\rtoth\.cursor\commands\housekeeping\*
      reason: lifecycle_archival_not_creation
    - path: C:\Users\rtoth\.cursor\commands\distillation\*
      reason: distillation_into_short_skeleton_not_creation
    - path: C:\Users\rtoth\.cursor\commands\research\*
      reason: research_playbooks_not_creation
    - path: C:\Users\rtoth\.cursor\commands\workflow-audit\*
      reason: audit_not_creation
    - path: C:\Users\rtoth\.cursor\commands\code-audit\*
      reason: audit_not_creation
    - path: C:\Users\rtoth\.cursor\commands\audit-engine\*
      reason: audit_orchestrator_not_creation
    - path: C:\Users\rtoth\.cursor\commands\n8n\*
      reason: not_creation_external_workflow_engine_corpus
    - path: C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-ingest.yaml
      reason: existing_session_lifecycle_not_creation
    - path: C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-audit.yaml
      reason: existing_session_lifecycle_not_creation
    - path: C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-checkpoint.yaml
      reason: existing_session_lifecycle_not_creation
    - path: C:\Users\rtoth\.cursor\commands\bootstrap\bootstrap-finalize.yaml
      reason: existing_session_lifecycle_not_creation

  overlap_stated_once:
    - "Closed-world enums, decision_trace, validation gates, anti-drift" — appears in bootstrap, planner, and corpus-unify; baked into router architecture once.
    - "Halt is preferred over guessing" — appears in bootstrap-start and planner; baked into anti_drift once.
    - "Operator-driven, never autonomous" — appears in bootstrap selection and planner gray_zone_policy; baked into clarification_protocol once.
    - "No silent default" — appears across all canonical sources; baked into anti_drift once.

  conflicts_surfaced:
    - id: C01
      summary: corpus_unify_automation_default_assumes_automatability_AND_router_anti_drift_never_guess_intent
      reconciliation: >
        Automation default applies to *inventorying gaps* in known
        execution paths, not to *inferring operator intent*. Router's
        anti_drift_never_guess_intent governs intent classification.
        Router's automation_inventory section governs gap surfacing. No
        actual conflict once scopes are separated. Surfaced here to
        prevent future drift.
    - id: C02
      summary: bootstrap_path_3_session_zero_AND_planner_one_project_per_session_AND_router_PROJECT_chain
      reconciliation: >
        All three reinforce: PROJECT chain runs bootstrap-start (Path 3)
        then planner.create_milestone_plan in a single session for a
        single project. No conflict — explicit alignment.

  router_original_synthesis:
    note: >
      The tier system, intent_anchor schema, and NORTH_STAR.md
      architecture are router-original — they did not come from any
      single canonical source. Bootstrap supplies project.summary +
      scope + non_scope as a project-level anchor; planner supplies
      project_mission as a plan-level anchor; corpus-unify supplies
      title + scope + automation_default as a unified-reference anchor.
      The router synthesizes these into a uniform tier-aware anchor
      contract that applies to every creation request type. This
      synthesis is governance-original and must be preserved verbatim
      against drift.
    components_synthesized:
      - tier_enum_with_TIER_0_through_TIER_3
      - intent_anchor_schema_with_purpose_non_scope_success_criterion_intent_brief_parent_intent_reference
      - north_star_md_paths_per_request_type
      - default_tier_per_request_type_table
      - step_6_confirm_tier_operator_dialog
      - gates_G13_G14_G15
      - validation_gates_V13_V14_V15
      - error_keys_TIER_NOT_CONFIRMED_TIER_0_NOT_ELIGIBLE_INTENT_ANCHOR_MISSING_INTENT_BRIEF_DEPTH_NOT_MET_TIER_DOWNGRADE_WITHOUT_JUSTIFICATION

  disambiguation:
    - term: "create"
      meanings:
        - lane_A: "operator wants a new artifact written to disk that did not exist before"  → router scope
        - lane_B: "operator wants to convert or transform an existing artifact"              → out of scope; route to audit/migrate/native_edit
        - lane_C: "operator wants to recover or supplement a broken bootstrap"               → out of scope; route to bootstrap recovery
    - term: "rule"
      meanings:
        - lane_A: ".cursor/rules/*.mdc Cursor rule"                  → request_type RULE
        - lane_B: "anti_drift rule inside this router or another command"  → not creation; out of scope
    - term: "command"
      meanings:
        - lane_A: "a command file under C:\\Users\\rtoth\\.cursor\\commands\\"  → request_type COMMAND
        - lane_B: "a slash command in chat to invoke the router"               → invocation, not creation
    - term: "skill"
      meanings:
        - lane_A: "SKILL.md authored from scratch"                   → request_type SKILL
        - lane_B: "migrating an existing rule or command into a skill"  → out of scope; route to migrate-to-skills
    - term: "plan"
      meanings:
        - lane_A: "milestone_plan / execution_plan / todo triplet for an existing project" → request_type PLAN
        - lane_B: "full project initialization including bootstrap"                         → request_type PROJECT

# ==============================================================================
# GAPS AND ASSUMPTIONS (open for operator review)
# ==============================================================================
gaps_and_assumptions:
  open_assumptions_pending_operator_confirmation:
    - id: A01
      assumption: source_breadth_limited_to_creation_relevant_subset_only
      affected: corpus_unify_provenance.sources_folded vs sources_excluded
      override_path: operator_widens_or_narrows_set
    - id: A02
      assumption: child_command_list_is_ten_PROJECT_BOOTSTRAP_DOCUMENT_CODE_RULE_SUBAGENT_SKILL_COMMAND_PLAN_CORPUS_UNIFY
      affected: governs_list and dispatch_table
      override_path: operator_adds_removes_or_splits_request_types
    - id: A03
      assumption: file_creation_only_no_infrastructure_request_types
      excluded_examples: [create_a_database, create_a_cron_job, create_a_container, create_a_queue, create_an_MCP_server]
      affected: request_type_enum
      override_path: operator_extends_enum
    - id: A04
      assumption: corpus_unify_is_both_methodology_authority_and_a_creation_child
      affected: authority_model and CORPUS_UNIFY dispatch
      override_path: operator_separates_concerns_if_undesired
    - id: A05
      assumption: COMMAND_request_type_uses_the_schema_shape_observed_in_existing_commands
      affected: COMMAND dispatch_table.required_inputs
      override_path: operator_locks_a_canonical_command_schema_template

  known_gaps:
    - id: G_GAP_01
      gap: create-document child is BUILT at canonical_path; nine other execution children remain STUB_PENDING_BUILD at runtime but draft COMMAND.md, NORTH_STAR.md, declarative yaml, and draft runners (handoff validation only, exit 2 DRAFT_ONLY) now live at canonical_path per governs until materialisation is implemented.
      mitigation: operator_authored_draft_specs_under_create_star_commands_2026
    - id: G_GAP_02
      gap: no_canonical_command_schema_template_file_exists_yet_so_COMMAND_dispatch_relies_on_hand_listed_required_inputs
      mitigation: hypothesis_label_until_a_canonical_template_is_authored
    - id: G_GAP_03
      gap: DOCUMENT_subtype_md_uses_native_write_with_no_template_authority
      mitigation: routes_to_native_write_only_when_no_skill_required_acknowledged_in_dispatch_table
    - id: G_GAP_04
      gap: workspace_skills_for_docx_pptx_xlsx_pdf_overlap_with_skills_cursor_versions_and_authority_priority_is_not_yet_locked
      mitigation: dispatch_table_prefers_workspace_skill_for_docx_and_skills_cursor_for_pptx_xlsx_pdf_until_operator_locks_otherwise
    - id: G_GAP_05
      gap: no_explicit_request_type_for_creating_a_new_subagent_at_user_level_versus_project_level_aside_from_scope_field
      mitigation: scope_field_inside_SUBAGENT_dispatch_resolves_path_template
    - id: G_GAP_06
      gap: no_request_type_for_creating_a_NEW_canonical_corpus_unify_skill_or_command_separate_from_invoking_corpus_unify
      mitigation: route_via_SKILL_or_COMMAND_request_type_when_creating_governance_artifact_for_corpus_unify
    - id: G_GAP_07
      gap: no_explicit_handling_for_creation_inside_a_project_root_that_lacks_02_working_subtree
      mitigation: G05_BOOTSTRAP_PRESENT_check_covers_this_via_REQUIRES_BOOTSTRAP
    - id: G_GAP_08
      gap: ungoverned_creation_outside_any_project_root_is_allowed_silently_when_G04_skipped
      example: "operator asks to create a docx in ~/Desktop with no project context"
      mitigation: decision_trace_should_record_governance_state=UNGOVERNED_NO_PROJECT_CONTEXT_when_target_outside_any_project_root
      hypothesis: this_is_acceptable_because_personal_scratchpad_creation_should_not_require_a_project_but_operator_should_confirm
    - id: G_GAP_09
      gap: path_normalization_between_windows_backslashes_and_forward_slashes_is_not_locked
      mitigation: dispatch_table_uses_backslashes_for_windows_command_paths_and_forward_slashes_for_dot_cursor_subtrees_until_operator_locks_a_canonical_form
    - id: G_GAP_10
      gap: no_explicit_conflict_resolution_when_operator_supplies_two_overrides_that_disagree
      example: "operator sets explicit_overwrite=true AND requests cancel in same payload"
      mitigation: hypothesis_last_received_wins_pending_operator_lock
    - id: G_GAP_11
      gap: NORTH_STAR_md_required_sections_are_specified_but_no_canonical_template_file_exists
      mitigation: each_TIER_3_child_command_when_authored_must_supply_a_section_template_router_only_validates_section_presence_not_section_content_quality
    - id: G_GAP_12
      gap: tier_promotion_after_dispatch_is_not_supported_a_TIER_1_artifact_cannot_be_upgraded_to_TIER_2_or_TIER_3_in_a_later_session_through_this_router
      mitigation: post_creation_tier_promotion_belongs_to_a_separate_command_NOT_THIS_ROUTER_router_locks_tier_at_creation_only
      hypothesis: a_promote-tier_command_may_be_authored_separately_in_the_future
    - id: G_GAP_13
      gap: TIER_0_decision_trace_in_session_only_persistence_has_no_audit_recovery_path_if_operator_realizes_after_dispatch_that_TIER_0_was_wrong
      mitigation: operator_can_re_run_at_higher_tier_against_the_same_target_path_with_explicit_overwrite_flag_to_promote_the_artifact
    - id: G_GAP_14
      status: MITIGATED_BY_G16_PROJECT_NORTH_STAR_SESSION_WARNING
      original_gap: parent_intent_reference_resolution_was_not_specified_for_artifacts_inside_a_project_root_lacking_NORTH_STAR_md
      resolution: G16_advisory_gate_fires_at_first_in_project_creation_request_per_session_offering_four_options_chain_now_or_defer_with_logged_justification_or_acknowledge_for_session_only_or_cancel

# ==============================================================================
# SELF-CHECK (per corpus-unify Step 5; must pass before router is considered fit)
# ==============================================================================
self_check:
  - q: every_creation_type_the_user_named_in_session_scope_request_is_handled_by_exactly_one_request_type
    target: PASS
  - q: every_request_type_has_a_stub_child_mapped_in_governs_list_and_dispatch_table
    target: PASS
  - q: any_user_phrasing_can_be_silently_misclassified
    target: NO
    enforced_by: classification_rule_collision_check_V09_plus_anti_drift_never_auto_choose
  - q: bootstrap_precondition_is_handled_for_every_project_bound_creation_type
    target: PASS
    enforced_by: G05_BOOTSTRAP_PRESENT
  - q: overwrite_is_never_silent
    target: PASS
    enforced_by: G07_NO_SILENT_OVERWRITE_plus_anti_drift_never_silently_overwrite
  - q: UNKNOWN_exit_is_always_reachable
    target: PASS
    enforced_by: R11_FALLBACK_UNKNOWN
  - q: decision_trace_is_emitted_on_every_terminus_state
    target: PASS
    enforced_by: output_contract_each_terminus_includes_decision_trace
  - q: transformation_audit_recovery_are_explicitly_rejected_with_pointers
    target: PASS
    enforced_by: error_policy_TRANSFORMATION_NOT_CREATION_AUDIT_NOT_CREATION_RECOVERY_NOT_CREATION
  - q: chain_dispatch_is_step_by_step_no_step_2_envelope_until_step_1_returns
    target: PASS
    enforced_by: output_contract_on_SUCCESS_CHAIN_FIRST_STEP
  - q: every_canonical_source_is_either_folded_or_explicitly_excluded_with_reason
    target: PASS
    enforced_by: corpus_unify_provenance.sources_folded_plus_sources_excluded
  - q: forbidden_silent_defaults_for_subtype_language_or_path
    target: PASS
    enforced_by: anti_drift_plus_subtype_resolution_rules_forbidden_lists
  - q: validation_gates_run_before_any_terminus_emission
    target: PASS
    enforced_by: validation_gates_V01_through_V15
  - q: every_request_type_has_a_default_tier_assigned_in_default_tier_per_request_type
    target: PASS
    enforced_by: default_tier_per_request_type_table_covers_all_eleven_request_types
  - q: TIER_0_is_operator_explicit_only_and_restricted_to_DOCUMENT_and_CODE
    target: PASS
    enforced_by: tier_definitions_TIER_0_eligible_request_types_plus_anti_drift_never_auto_default_to_TIER_0_plus_G15_TIER_CONFIRMED
  - q: TIER_3_artifacts_always_emit_NORTH_STAR_md_at_canonical_path
    target: PASS
    enforced_by: G14_INTENT_BRIEF_DEPTH_MET_plus_north_star_md_paths_plus_V14
  - q: tier_is_confirmed_by_operator_before_dispatch_envelope_freezes
    target: PASS
    enforced_by: step_6_confirm_tier_plus_G15_TIER_CONFIRMED_plus_anti_drift_never_skip_step_6
  - q: intent_anchor_required_at_TIER_1_TIER_2_TIER_3_and_skipped_only_at_TIER_0
    target: PASS
    enforced_by: G13_INTENT_ANCHOR_PRESENT_with_when_clause_tier_locked_not_TIER_0
  - q: decision_trace_persistence_flag_set_correctly_per_tier
    target: PASS
    enforced_by: V13_consistency_check_plus_V15_TIER_0_specific_check
  - q: parent_intent_reference_resolves_for_in_project_creation_and_is_null_for_ungoverned
    target: PASS
    enforced_by: intent_anchor_schema_parent_intent_reference_required_when_clause
  - q: PROJECT_SKILL_COMMAND_CORPUS_UNIFY_can_never_be_downgraded_below_TIER_3
    target: PASS
    enforced_by: default_tier_per_request_type_downgrade_forbidden_true_plus_anti_drift_never_accept_downgrade_attempt_plus_TIER_DOWNGRADE_FORBIDDEN_error_key
  - q: existing_project_without_NORTH_STAR_md_triggers_session_warning_at_first_creation_request
    target: PASS
    enforced_by: G16_PROJECT_NORTH_STAR_SESSION_WARNING_plus_V16
  - q: G16_session_suppression_does_not_carry_across_session_boundaries
    target: PASS
    enforced_by: anti_drift_never_apply_G16_session_suppression_across_session_boundaries_plus_suppression_key_includes_session_id

# ==============================================================================
# QUICK LOOKUP
# ==============================================================================
quick_lookup:
  - need: "stand up a brand-new project from zero"
    request_type: PROJECT
    default_tier: TIER_3
    chain: [bootstrap-start (Path 3), planner.create_milestone_plan, NORTH_STAR.md creation, optional create-rule]
  - need: "add a bootstrap to an existing project tree"
    request_type: BOOTSTRAP
    target: bootstrap-start (Path 3 with project_root present)
  - need: "create a milestone or execution plan for an existing project"
    request_type: PLAN
    operation: create_milestone_plan or create_execution_plan
  - need: "make a new word/excel/powerpoint/pdf/markdown/html/txt/yaml/json/csv document"
    request_type: DOCUMENT
    subtype: from document_subtype_enum
  - need: "create a source code file or module"
    request_type: CODE
    subtype: language_label
  - need: "create a Cursor rule"
    request_type: RULE
    target_path_template: "{project_root}/.cursor/rules/{rule_name}.mdc"
  - need: "create a Cursor subagent"
    request_type: SUBAGENT
    target_path_template:
      project: "{project_root}/.cursor/agents/{subagent_name}.md"
      user:    "~/.cursor/agents/{subagent_name}.md"
  - need: "create a SKILL.md from scratch"
    request_type: SKILL
    target_path_template:
      project: "{project_root}/.cursor/skills/{skill_name}/SKILL.md"
      user:    "~/.cursor/skills/{skill_name}/SKILL.md"
  - need: "create a new command file"
    request_type: COMMAND
    target_path_template: "C:\\Users\\rtoth\\.cursor\\commands\\{command_name}\\COMMAND.md"
  - need: "merge a folder of overlapping docs into one unified reference"
    request_type: CORPUS_UNIFY
  - need: "review existing code or workflow"
    request_type: NOT_HANDLED_BY_ROUTER
    pointer: C:\Users\rtoth\.cursor\commands\audit-engine\COMMAND.md
  - need: "recover a broken bootstrap or supplement a session"
    request_type: NOT_HANDLED_BY_ROUTER
    pointer: C:\Users\rtoth\.cursor\commands\bootstrap\COMMAND.md#recovery_protocol
  - need: "convert an existing file to a different format"
    request_type: NOT_HANDLED_BY_ROUTER
    pointer: skills-cursor/migrate-to-skills (for rule/command→skill) OR native_edit (for content edits)
  - need: "throwaway scratch file, no documentation, no anchor"
    request_type: DOCUMENT_or_CODE_only
    tier: TIER_0
    rule: operator_must_explicitly_declare_TIER_0_router_never_defaults_to_it
```
