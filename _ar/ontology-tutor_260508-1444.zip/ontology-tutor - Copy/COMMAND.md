---
name: ontology-tutor
description: >-
  Ontology engineering for TypeDB-shaped models, folder taxonomies, and (mode 2)
  SQL embodiment. Read canonical SKILL.md and ROUTER.yaml, then follow the tutor
  contract (Sources 1–3, decision traces).
---

# ontology-tutor

## Canonical files (versioned in C:\dev)

| File | Path |
| --- | --- |
| SKILL.md | `c:\dev\40-49-ai-agents-and-prompts\43-rules-skills-subagents\43.01-custom-skills\ontology-tutor\SKILL.md` |
| ROUTER.yaml | `c:\dev\40-49-ai-agents-and-prompts\43-rules-skills-subagents\43.01-custom-skills\ontology-tutor\ROUTER.yaml` |

## Cursor pick-up (optional junction only)

**Authoritative copies live only under `C:\dev`** (see **AGENTS-01-dev §5**). Do not save or maintain canonical **`SKILL.md`** / **`COMMAND.md`** under **`%USERPROFILE%\.cursor\skills-cursor\`**. If Cursor only discovers skills under the profile tree, you MAY create a **junction from profile to dev** (e.g. `%USERPROFILE%\.cursor\skills-cursor\ontology-tutor\` → `...\43.01-custom-skills\ontology-tutor\`) so the editor reads the `C:\dev` files — not the reverse.

## Decision trace output (optional)

YAML traces from `/validate` and `/schema` belong under **`47.04-ontology-decision-traces`** (see that ID’s `precedents.yaml`).

## Session use

1. Confirm **mode 1** (Pure TypeDB) vs **mode 2** (SQL embodiment) per SKILL.md.
2. Read **ROUTER.yaml** for routing tokens, snapshot bindings, and evidence-refresh rules.
3. Execute only tools and phases allowed in the SKILL contract; do not use live `typedb-mcp` unless the operator overrides.
